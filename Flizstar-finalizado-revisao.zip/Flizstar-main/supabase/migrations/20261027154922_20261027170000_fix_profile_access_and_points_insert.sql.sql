/*
# Fix FLIZSTAR profile access and customer_points insert

1. Security Fixes
- GRANT UPDATE ON profiles TO authenticated: o painel admin precisa de UPDATE para alterar level, xp, is_banned, nick, bio. A política RLS profiles_update_manager já existe, mas faltava o grant de UPDATE para o role authenticated, fazendo toda alteração de perfil falhar com "permission denied" antes da RLS ser avaliada.
- Removida a política duplicada profiles_select_own (substituída por profiles_select_own_or_manager que já cobre acesso próprio + gerente).
- Tornar customer_points.customer_id nullable: o INSERT do adjust_points quando o cliente não tem registro de pontos enviava apenas customer_email e balance, mas customer_id era NOT NULL sem default, causando erro de constraint. Agora nullable permite criar registro sem customer_id.

2. Important Notes
- Não altera dados existentes.
- Não altera outras tabelas.
- Não ativa nem desativa eventos de Natal.
- Preserva todas as políticas existentes.
- Cada cliente continua podendo ver apenas seu próprio perfil (id = auth.uid()) e seus próprios dados privados.
- Gerentes continuam podendo consultar todos os perfis via private.is_manager().
*/

-- Grant UPDATE on profiles to authenticated (needed for manager actions)
GRANT UPDATE ON public.profiles TO authenticated;

-- Remove duplicate policy (profiles_select_own is superseded by profiles_select_own_or_manager)
DROP POLICY IF EXISTS "profiles_select_own" ON public.profiles;

-- Make customer_points.customer_id nullable so inserts without it succeed
ALTER TABLE public.customer_points ALTER COLUMN customer_id DROP NOT NULL;