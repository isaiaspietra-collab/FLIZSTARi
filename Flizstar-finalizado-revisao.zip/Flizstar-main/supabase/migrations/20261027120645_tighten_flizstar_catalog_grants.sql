/*
# Tighten FLIZSTAR catalog grants

1. Security Changes
- Remove INSERT, UPDATE, and DELETE privileges on `products` from the anonymous role.
- Remove every privilege on `profiles` from the anonymous role.
- Keep only SELECT on `profiles` for authenticated users, matching the existing own-profile policy.

2. Important Notes
- Row Level Security policies remain the authority for which rows are visible or writable.
- Managers continue to use the existing manager-only product policies.
- Customers and anonymous visitors can only read active public products.
*/

REVOKE INSERT, UPDATE, DELETE ON public.products FROM anon;
REVOKE ALL ON public.profiles FROM anon;
REVOKE INSERT, UPDATE, DELETE ON public.profiles FROM authenticated;
GRANT SELECT ON public.profiles TO authenticated;