/*
# Create FLIZSTAR manager access and products

1. New Tables
- `profiles` stores the account role for each Supabase Auth user. The email is retained for the account owner and the role is either `customer` or `manager`.
- `products` stores the public store catalog, including name, description, game, category, optional image URL, price in BRL, active state, and a demo marker.

2. Seed Data
- Adds the eight existing FLIZSTAR demonstration products when the catalog is empty, preserving the current storefront experience.
- Seeded products remain marked as demonstrations and do not represent real stock or sales.

3. Security
- Enables Row Level Security on both tables.
- Public and signed-in visitors may read active products only.
- Signed-in managers may read all products and create, update, or delete products.
- Customers cannot create, update, or delete products.
- Each signed-in user may read only their own profile.
- New Auth users receive a customer profile automatically.
- The manager role is stored in the database and is never accepted from the browser.

4. Important Notes
- This migration does not create manager accounts because email addresses and passwords were not provided.
- After two real manager accounts are created through Supabase Auth, their `profiles.role` values must be promoted to `manager` by an authorized project administrator.
- Payment providers, orders, Pix QR codes, and payment confirmation are intentionally outside this change.
*/

CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  role text NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'manager')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  game text NOT NULL,
  category text NOT NULL,
  image_url text,
  price numeric(10, 2) NOT NULL CHECK (price >= 0),
  is_active boolean NOT NULL DEFAULT true,
  is_demo boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS products_active_game_idx ON public.products (is_active, game);

CREATE OR REPLACE FUNCTION public.is_manager()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND role = 'manager'
  );
$$;

CREATE OR REPLACE FUNCTION public.handle_new_flizstar_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email)
  VALUES (NEW.id, COALESCE(NEW.email, ''))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created_flizstar ON auth.users;
CREATE TRIGGER on_auth_user_created_flizstar
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_flizstar_user();

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON public.profiles TO authenticated;
GRANT SELECT ON public.products TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.products TO authenticated;

REVOKE ALL ON FUNCTION public.is_manager() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_manager() TO authenticated;
REVOKE ALL ON FUNCTION public.handle_new_flizstar_user() FROM PUBLIC, anon, authenticated;

DROP POLICY IF EXISTS "profiles_select_own" ON public.profiles;
CREATE POLICY "profiles_select_own" ON public.profiles
  FOR SELECT TO authenticated
  USING (id = auth.uid());

DROP POLICY IF EXISTS "products_select_public_or_manager" ON public.products;
CREATE POLICY "products_select_public_or_manager" ON public.products
  FOR SELECT TO anon, authenticated
  USING (is_active = true OR public.is_manager());

DROP POLICY IF EXISTS "products_insert_manager" ON public.products;
CREATE POLICY "products_insert_manager" ON public.products
  FOR INSERT TO authenticated
  WITH CHECK (public.is_manager());

DROP POLICY IF EXISTS "products_update_manager" ON public.products;
CREATE POLICY "products_update_manager" ON public.products
  FOR UPDATE TO authenticated
  USING (public.is_manager())
  WITH CHECK (public.is_manager());

DROP POLICY IF EXISTS "products_delete_manager" ON public.products;
CREATE POLICY "products_delete_manager" ON public.products
  FOR DELETE TO authenticated
  USING (public.is_manager());

INSERT INTO public.products (name, description, game, category, price, is_demo)
SELECT seed.name, seed.description, seed.game, seed.category, seed.price, true
FROM (VALUES
  ('Nebula Bundle', 'Pacote visual de demonstração com estética cósmica.', 'Roblox', 'Itens', 29.90::numeric),
  ('Passe Estelar', 'Exemplo de passe premium para a temporada.', 'Free Fire', 'Passe', 39.90::numeric),
  ('Gem Pack 500', 'Quantidade ilustrativa de gemas para sua coleção.', 'Brawl Stars', 'Moeda', 24.90::numeric),
  ('Elite Crate', 'Caixa temática de demonstração para o inventário.', 'PUBG', 'Caixas', 49.90::numeric),
  ('Star Avatar', 'Avatar conceitual com acabamento neon.', 'Roblox', 'Avatares', 19.90::numeric),
  ('Skin Eclipse', 'Skin demonstrativa com detalhes luminosos.', 'Free Fire', 'Skins', 34.90::numeric),
  ('Mega Box', 'Oferta visual de exemplo, sem entrega real.', 'Brawl Stars', 'Caixas', 44.90::numeric),
  ('Royale Pass', 'Modelo de passe para apresentar a experiência.', 'PUBG', 'Passe', 54.90::numeric)
) AS seed(name, description, game, category, price)
WHERE NOT EXISTS (SELECT 1 FROM public.products);