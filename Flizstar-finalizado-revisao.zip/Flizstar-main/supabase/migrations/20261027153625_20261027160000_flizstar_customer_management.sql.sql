/*
# FLIZSTAR customer management — profile fields, inventory, admin action log

1. Modified Tables
- `profiles` — adiciona colunas para o perfil avançado do cliente:
  - `nick` (text, nullable): apelido do cliente na plataforma.
  - `bio` (text, nullable): biografia/observação do cliente.
  - `level` (integer, default 1): nível do cliente.
  - `xp` (integer, default 0): experiência acumulada.
  - `is_banned` (boolean, default false): marca de banimento.
  - `updated_at` (timestamptz, default now()): controle de atualização.

2. New Tables
- `customer_inventory` — inventário de itens do cliente (produtos adquiridos, presentes recebidos).
  - `id` (uuid, primary key)
  - `customer_id` (uuid, references profiles, on delete cascade)
  - `customer_email` (text)
  - `product_id` (uuid, references products, on delete set null)
  - `product_name` (text)
  - `source` (text: 'purchase', 'gift', 'event', 'admin')
  - `granted_at` (timestamptz, default now())

- `admin_action_log` — registro de ações administrativas com justificativa.
  - `id` (uuid, primary key)
  - `manager_id` (uuid, references profiles, on delete set null)
  - `manager_email` (text)
  - `target_customer_id` (uuid, references profiles, on delete cascade)
  - `target_customer_email` (text)
  - `action` (text: 'ban', 'unban', 'adjust_points', 'grant_item', 'revoke_item', 'note', 'promote', 'demote')
  - `reason` (text): justificativa obrigatória
  - `details` (text, nullable): detalhes adicionais
  - `created_at` (timestamptz, default now())

3. Security
- RLS habilitado em `customer_inventory` e `admin_action_log`.
- Clientes autenticados podem ler apenas seu próprio inventário.
- Gerentes (private.is_manager()) podem ler e gerenciar todos os inventários.
- Gerentes podem ler todas as ações administrativas (log) e inserir registros de log.
- Clientes não podem ler o log de ações administrativas.
- UPDATE em profiles: apenas gerentes podem atualizar campos administrativos (level, xp, is_banned, nick, bio).
- Concede SELECT adicional em profiles para authenticated ler perfis básicos (necessário para o painel de clientes).

4. Important Notes
- Não altera dados existentes de profiles nem de outras tabelas.
- Não ativa nem desativa eventos de Natal.
- Todas as ações administrativas exigem justificativa gravada no log.
- O evento de Natal permanece desativado.
*/

-- Add profile columns (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'nick') THEN
    ALTER TABLE public.profiles ADD COLUMN nick text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'bio') THEN
    ALTER TABLE public.profiles ADD COLUMN bio text;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'level') THEN
    ALTER TABLE public.profiles ADD COLUMN level integer NOT NULL DEFAULT 1;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'xp') THEN
    ALTER TABLE public.profiles ADD COLUMN xp integer NOT NULL DEFAULT 0;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'is_banned') THEN
    ALTER TABLE public.profiles ADD COLUMN is_banned boolean NOT NULL DEFAULT false;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'profiles' AND column_name = 'updated_at') THEN
    ALTER TABLE public.profiles ADD COLUMN updated_at timestamptz NOT NULL DEFAULT now();
  END IF;
END $$;

-- Allow authenticated users to read profiles (manager needs full list; customers already restricted by policy)
-- The existing profiles_select_own policy only lets users see their own profile.
-- Add a manager-read-all policy so the admin panel can list all customers.
DROP POLICY IF EXISTS "profiles_select_own_or_manager" ON public.profiles;
CREATE POLICY "profiles_select_own_or_manager" ON public.profiles
  FOR SELECT TO authenticated
  USING (id = auth.uid() OR private.is_manager());

-- Allow managers to update profiles (level, xp, is_banned, nick, bio, role)
DROP POLICY IF EXISTS "profiles_update_manager" ON public.profiles;
CREATE POLICY "profiles_update_manager" ON public.profiles
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

-- customer_inventory table
CREATE TABLE IF NOT EXISTS public.customer_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  customer_email text NOT NULL DEFAULT '',
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  product_name text NOT NULL DEFAULT '',
  source text NOT NULL DEFAULT 'admin' CHECK (source IN ('purchase','gift','event','admin')),
  granted_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.customer_inventory ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.customer_inventory TO authenticated;

DROP POLICY IF EXISTS "inventory_select_own_or_manager" ON public.customer_inventory;
CREATE POLICY "inventory_select_own_or_manager" ON public.customer_inventory
  FOR SELECT TO authenticated
  USING (customer_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "inventory_insert_manager" ON public.customer_inventory;
CREATE POLICY "inventory_insert_manager" ON public.customer_inventory
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "inventory_update_manager" ON public.customer_inventory;
CREATE POLICY "inventory_update_manager" ON public.customer_inventory
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "inventory_delete_manager" ON public.customer_inventory;
CREATE POLICY "inventory_delete_manager" ON public.customer_inventory
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- admin_action_log table
CREATE TABLE IF NOT EXISTS public.admin_action_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  manager_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  manager_email text NOT NULL DEFAULT '',
  target_customer_id uuid REFERENCES public.profiles(id) ON DELETE CASCADE,
  target_customer_email text NOT NULL DEFAULT '',
  action text NOT NULL DEFAULT 'note' CHECK (action IN ('ban','unban','adjust_points','grant_item','revoke_item','note','promote','demote','set_level','set_xp')),
  reason text NOT NULL DEFAULT '',
  details text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_action_log ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON public.admin_action_log TO authenticated;

DROP POLICY IF EXISTS "actionlog_select_manager" ON public.admin_action_log;
CREATE POLICY "actionlog_select_manager" ON public.admin_action_log
  FOR SELECT TO authenticated
  USING (private.is_manager());

DROP POLICY IF EXISTS "actionlog_insert_manager" ON public.admin_action_log;
CREATE POLICY "actionlog_insert_manager" ON public.admin_action_log
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

CREATE INDEX IF NOT EXISTS inventory_customer_idx ON public.customer_inventory (customer_id);
CREATE INDEX IF NOT EXISTS actionlog_target_idx ON public.admin_action_log (target_customer_id, created_at);