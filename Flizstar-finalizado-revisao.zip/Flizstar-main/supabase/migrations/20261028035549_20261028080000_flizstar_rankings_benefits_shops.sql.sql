/*
# FLIZSTAR Rankings, Benefits, and Customer Shops

## Overview
Adds infrastructure for:
1. Top Global ranking (by current points balance) — top 10 public, Top 1 & Top 2 get benefits
2. Top Investidores ranking (by total spent on valid orders) — top 5, recalculated each 6-month semester, tiered benefits
3. Customer shops — the Top 1 investor per semester can create their own shop with products and orders
4. Benefit history tracking — records when benefits are granted/revoked so permanent items are preserved

## New Tables
- ranking_periods: 6-month semesters for Top Investidores
- top_investidores_standings: materialized top 5 per semester
- benefit_history: audit log of granted/revoked benefits
- customer_shops: shop owned by Top 1 investor
- customer_shop_products: products in a customer shop
- customer_shop_orders: orders placed on customer shop products

## Security
- All tables RLS enabled, grants scoped to authenticated
- private.is_manager() reused for manager-only operations
- can_open_shop(uuid) SECURITY DEFINER checks Top 1 investor status
- recompute_top_investidores() and close_semester_and_open_new() manager-callable
- Customers cannot alter rankings, points, total spent, or administrative benefits
- Christmas and Casino events remain untouched

## Important Notes
1. Top Global ranking computed live via view — no stored standings, no RLS on view (inherits from underlying tables)
2. Top Investidores standings stored, recalculated by recompute_top_investidores()
3. Benefit history preserves permanent items when position is lost
4. Customer shops restricted to current Top 1 investor via can_open_shop()
*/

-- ===========================================================================
-- 1. ranking_periods
-- ===========================================================================
CREATE TABLE IF NOT EXISTS public.ranking_periods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  kind text NOT NULL CHECK (kind IN ('top_investidores')),
  starts_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz NOT NULL DEFAULT (now() + interval '6 months'),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'closed')),
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.ranking_periods ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.ranking_periods TO authenticated;

DROP POLICY IF EXISTS "ranking_periods_select_all" ON public.ranking_periods;
CREATE POLICY "ranking_periods_select_all"
  ON public.ranking_periods FOR SELECT TO authenticated USING (true);

CREATE UNIQUE INDEX IF NOT EXISTS ranking_periods_one_active_per_kind
  ON public.ranking_periods (kind) WHERE status = 'active';

-- ===========================================================================
-- 2. top_investidores_standings
-- ===========================================================================
CREATE TABLE IF NOT EXISTS public.top_investidores_standings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period_id uuid NOT NULL REFERENCES public.ranking_periods(id) ON DELETE CASCADE,
  customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  customer_email text NOT NULL DEFAULT '',
  total_spent numeric NOT NULL DEFAULT 0,
  rank_position integer NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (period_id, customer_id)
);

ALTER TABLE public.top_investidores_standings ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.top_investidores_standings TO authenticated;

DROP POLICY IF EXISTS "standings_select_all" ON public.top_investidores_standings;
CREATE POLICY "standings_select_all"
  ON public.top_investidores_standings FOR SELECT TO authenticated USING (true);

-- ===========================================================================
-- 3. benefit_history
-- ===========================================================================
CREATE TABLE IF NOT EXISTS public.benefit_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  customer_email text NOT NULL DEFAULT '',
  benefit text NOT NULL,
  source text NOT NULL CHECK (source IN ('top_global', 'top_investidores', 'admin')),
  status text NOT NULL DEFAULT 'granted' CHECK (status IN ('granted', 'revoked')),
  details text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.benefit_history ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON public.benefit_history TO authenticated;

DROP POLICY IF EXISTS "benefits_select_own_or_manager" ON public.benefit_history;
CREATE POLICY "benefits_select_own_or_manager"
  ON public.benefit_history FOR SELECT
  TO authenticated USING (customer_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "benefits_insert_manager" ON public.benefit_history;
CREATE POLICY "benefits_insert_manager"
  ON public.benefit_history FOR INSERT
  TO authenticated WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "benefits_update_manager" ON public.benefit_history;
CREATE POLICY "benefits_update_manager"
  ON public.benefit_history FOR UPDATE
  TO authenticated USING (private.is_manager()) WITH CHECK (private.is_manager());

-- ===========================================================================
-- 4. customer_shops + products + orders (tables first)
-- ===========================================================================
CREATE TABLE IF NOT EXISTS public.customer_shops (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  owner_email text NOT NULL DEFAULT '',
  name text NOT NULL DEFAULT '',
  slug text UNIQUE,
  is_open boolean NOT NULL DEFAULT false,
  is_suspended boolean NOT NULL DEFAULT false,
  suspension_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.customer_shop_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shop_id uuid NOT NULL REFERENCES public.customer_shops(id) ON DELETE CASCADE,
  owner_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  name text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  game text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT '',
  price numeric NOT NULL DEFAULT 0,
  image_url text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.customer_shop_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  shop_id uuid NOT NULL REFERENCES public.customer_shops(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES public.customer_shop_products(id) ON DELETE CASCADE,
  buyer_id uuid REFERENCES public.profiles(id) ON DELETE SET NULL,
  buyer_email text NOT NULL DEFAULT '',
  nick text NOT NULL DEFAULT '',
  price numeric NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'delivered', 'cancelled')),
  order_number text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ===========================================================================
-- 5. Function: can_open_shop(uuid) — now tables exist
-- ===========================================================================
CREATE OR REPLACE FUNCTION public.can_open_shop(p_user_id uuid)
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.top_investidores_standings s
    JOIN public.ranking_periods rp ON rp.id = s.period_id
    WHERE rp.kind = 'top_investidores' AND rp.status = 'active'
    AND s.customer_id = p_user_id AND s.rank_position = 1
  );
$$;

REVOKE EXECUTE ON FUNCTION public.can_open_shop(uuid) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_open_shop(uuid) TO authenticated;

-- ===========================================================================
-- 6. customer_shops RLS + policies
-- ===========================================================================
ALTER TABLE public.customer_shops ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON public.customer_shops TO authenticated;

DROP POLICY IF EXISTS "shops_select_all" ON public.customer_shops;
CREATE POLICY "shops_select_all"
  ON public.customer_shops FOR SELECT
  TO authenticated USING (owner_id = auth.uid() OR private.is_manager() OR (is_open = true AND is_suspended = false));

DROP POLICY IF EXISTS "shops_insert_owner" ON public.customer_shops;
CREATE POLICY "shops_insert_owner"
  ON public.customer_shops FOR INSERT
  TO authenticated WITH CHECK (owner_id = auth.uid() AND public.can_open_shop(auth.uid()));

DROP POLICY IF EXISTS "shops_update_owner_or_manager" ON public.customer_shops;
CREATE POLICY "shops_update_owner_or_manager"
  ON public.customer_shops FOR UPDATE
  TO authenticated USING (owner_id = auth.uid() OR private.is_manager()) WITH CHECK (owner_id = auth.uid() OR private.is_manager());

-- ===========================================================================
-- 7. customer_shop_products RLS + policies
-- ===========================================================================
ALTER TABLE public.customer_shop_products ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.customer_shop_products TO authenticated;

DROP POLICY IF EXISTS "shop_products_select_all" ON public.customer_shop_products;
CREATE POLICY "shop_products_select_all"
  ON public.customer_shop_products FOR SELECT
  TO authenticated USING (
    owner_id = auth.uid()
    OR private.is_manager()
    OR (
      is_active = true
      AND EXISTS (
        SELECT 1 FROM public.customer_shops s
        WHERE s.id = customer_shop_products.shop_id
        AND s.is_open = true AND s.is_suspended = false
      )
    )
  );

DROP POLICY IF EXISTS "shop_products_insert_owner" ON public.customer_shop_products;
CREATE POLICY "shop_products_insert_owner"
  ON public.customer_shop_products FOR INSERT
  TO authenticated WITH CHECK (owner_id = auth.uid());

DROP POLICY IF EXISTS "shop_products_update_owner_or_manager" ON public.customer_shop_products;
CREATE POLICY "shop_products_update_owner_or_manager"
  ON public.customer_shop_products FOR UPDATE
  TO authenticated USING (owner_id = auth.uid() OR private.is_manager()) WITH CHECK (owner_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "shop_products_delete_owner_or_manager" ON public.customer_shop_products;
CREATE POLICY "shop_products_delete_owner_or_manager"
  ON public.customer_shop_products FOR DELETE
  TO authenticated USING (owner_id = auth.uid() OR private.is_manager());

-- ===========================================================================
-- 8. customer_shop_orders RLS + policies
-- ===========================================================================
ALTER TABLE public.customer_shop_orders ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON public.customer_shop_orders TO authenticated;

DROP POLICY IF EXISTS "shop_orders_select_owner_buyer_manager" ON public.customer_shop_orders;
CREATE POLICY "shop_orders_select_owner_buyer_manager"
  ON public.customer_shop_orders FOR SELECT
  TO authenticated USING (
    buyer_id = auth.uid()
    OR private.is_manager()
    OR EXISTS (
      SELECT 1 FROM public.customer_shops s
      WHERE s.id = customer_shop_orders.shop_id AND s.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "shop_orders_insert_buyer" ON public.customer_shop_orders;
CREATE POLICY "shop_orders_insert_buyer"
  ON public.customer_shop_orders FOR INSERT
  TO authenticated WITH CHECK (buyer_id = auth.uid() OR buyer_id IS NULL);

DROP POLICY IF EXISTS "shop_orders_update_owner_or_manager" ON public.customer_shop_orders;
CREATE POLICY "shop_orders_update_owner_or_manager"
  ON public.customer_shop_orders FOR UPDATE
  TO authenticated USING (
    private.is_manager()
    OR EXISTS (
      SELECT 1 FROM public.customer_shops s
      WHERE s.id = customer_shop_orders.shop_id AND s.owner_id = auth.uid()
    )
  ) WITH CHECK (
    private.is_manager()
    OR EXISTS (
      SELECT 1 FROM public.customer_shops s
      WHERE s.id = customer_shop_orders.shop_id AND s.owner_id = auth.uid()
    )
  );

-- ===========================================================================
-- 9. View: top_global_ranking (live, by points balance; no RLS on views)
-- ===========================================================================
CREATE OR REPLACE VIEW public.top_global_ranking AS
SELECT
  p.id AS customer_id,
  p.email,
  p.nick,
  p.level,
  p.xp,
  COALESCE(cp.balance, 0) AS points_balance,
  ROW_NUMBER() OVER (ORDER BY COALESCE(cp.balance, 0) DESC, p.created_at ASC) AS rank_position
FROM public.profiles p
LEFT JOIN public.customer_points cp ON cp.customer_id = p.id
WHERE p.role = 'customer' AND p.is_banned = false;

GRANT SELECT ON public.top_global_ranking TO authenticated;

-- ===========================================================================
-- 10. Functions: recompute + close_semester
-- ===========================================================================
CREATE OR REPLACE FUNCTION public.recompute_top_investidores()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_period_id uuid;
  v_rec record;
  v_rank int;
BEGIN
  SELECT id INTO v_period_id
  FROM public.ranking_periods
  WHERE kind = 'top_investidores' AND status = 'active'
  ORDER BY starts_at DESC LIMIT 1;

  IF v_period_id IS NULL THEN
    RAISE EXCEPTION 'No active top_investidores period found';
  END IF;

  DELETE FROM public.top_investidores_standings WHERE period_id = v_period_id;

  v_rank := 0;
  FOR v_rec IN
    SELECT
      o.customer_id,
      o.customer_email,
      SUM(o.price) AS total_spent
    FROM public.orders o
    WHERE o.customer_id IS NOT NULL
    AND o.status IN ('paid', 'delivered')
    AND o.is_demo = false
    AND o.created_at >= (SELECT starts_at FROM public.ranking_periods WHERE id = v_period_id)
    AND o.created_at < COALESCE(
      (SELECT ends_at FROM public.ranking_periods WHERE id = v_period_id), now() + interval '100 years'
    )
    GROUP BY o.customer_id, o.customer_email
    ORDER BY SUM(o.price) DESC
    LIMIT 5
  LOOP
    v_rank := v_rank + 1;
    INSERT INTO public.top_investidores_standings (period_id, customer_id, customer_email, total_spent, rank_position, updated_at)
    VALUES (v_period_id, v_rec.customer_id, v_rec.customer_email, v_rec.total_spent, v_rank, now())
    ON CONFLICT (period_id, customer_id) DO UPDATE SET
      total_spent = EXCLUDED.total_spent,
      rank_position = EXCLUDED.rank_position,
      updated_at = now();
  END LOOP;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.recompute_top_investidores() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.recompute_top_investidores() TO authenticated;

CREATE OR REPLACE FUNCTION public.close_semester_and_open_new()
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old_id uuid;
  v_new_id uuid;
  v_now timestamptz := now();
BEGIN
  SELECT id INTO v_old_id
  FROM public.ranking_periods
  WHERE kind = 'top_investidores' AND status = 'active'
  ORDER BY starts_at DESC LIMIT 1;

  IF v_old_id IS NOT NULL THEN
    UPDATE public.ranking_periods SET status = 'closed', ends_at = v_now WHERE id = v_old_id;
  END IF;

  INSERT INTO public.ranking_periods (kind, starts_at, ends_at, status, created_at)
  VALUES ('top_investidores', v_now, v_now + interval '6 months', 'active', v_now)
  RETURNING id INTO v_new_id;

  PERFORM public.recompute_top_investidores();

  RETURN v_new_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.close_semester_and_open_new() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.close_semester_and_open_new() TO authenticated;

-- ===========================================================================
-- 11. Seed initial active semester
-- ===========================================================================
INSERT INTO public.ranking_periods (kind, starts_at, ends_at, status, created_at)
SELECT 'top_investidores', date_trunc('month', now()), date_trunc('month', now()) + interval '6 months', 'active', now()
WHERE NOT EXISTS (
  SELECT 1 FROM public.ranking_periods WHERE kind = 'top_investidores' AND status = 'active'
);

-- ===========================================================================
-- 12. Indexes
-- ===========================================================================
CREATE INDEX IF NOT EXISTS idx_top_investidores_period ON public.top_investidores_standings (period_id);
CREATE INDEX IF NOT EXISTS idx_top_investidores_customer ON public.top_investidores_standings (customer_id);
CREATE INDEX IF NOT EXISTS idx_benefit_history_customer ON public.benefit_history (customer_id);
CREATE INDEX IF NOT EXISTS idx_customer_shops_owner ON public.customer_shops (owner_id);
CREATE INDEX IF NOT EXISTS idx_customer_shop_products_shop ON public.customer_shop_products (shop_id);
CREATE INDEX IF NOT EXISTS idx_customer_shop_orders_shop ON public.customer_shop_orders (shop_id);
CREATE INDEX IF NOT EXISTS idx_orders_customer_id_status ON public.orders (customer_id, status);
