/*
# Keep manager authorization private

1. Security Changes
- Move the manager-role check out of the public API schema into a private schema.
- Update product policies to use the private authorization function.
- Keep execution limited to authenticated sessions so the database can evaluate manager policies without exposing an RPC endpoint in the public schema.

2. Important Notes
- This does not change product access behavior.
- Anonymous visitors still read only active products.
- Customers still cannot create, edit, or delete products.
*/

CREATE SCHEMA IF NOT EXISTS private;

CREATE OR REPLACE FUNCTION private.is_manager()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE id = auth.uid()
      AND role = 'manager'
  );
$$;

REVOKE ALL ON FUNCTION private.is_manager() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.is_manager() TO authenticated;

DROP POLICY IF EXISTS "products_select_public_or_manager" ON public.products;
CREATE POLICY "products_select_public_or_manager" ON public.products
  FOR SELECT TO anon, authenticated
  USING (is_active = true OR private.is_manager());

DROP POLICY IF EXISTS "products_insert_manager" ON public.products;
CREATE POLICY "products_insert_manager" ON public.products
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "products_update_manager" ON public.products;
CREATE POLICY "products_update_manager" ON public.products
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "products_delete_manager" ON public.products;
CREATE POLICY "products_delete_manager" ON public.products
  FOR DELETE TO authenticated
  USING (private.is_manager());

DROP FUNCTION IF EXISTS public.is_manager();