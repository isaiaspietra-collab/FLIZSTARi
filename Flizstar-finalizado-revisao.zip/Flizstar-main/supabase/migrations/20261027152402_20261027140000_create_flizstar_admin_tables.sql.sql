/*
# Create FLIZSTAR admin tables

1. New Tables
- `orders` — pedidos feitos na loja (demonstrativos e reais). Armazena produto, nick, e-mail, valor, status, método de pagamento e timestamps.
- `trade_offers` — trocas propostas pela comunidade. Armazena jogo, oferece, procura, usuário, status e timestamps.
- `golden_tickets` — Ticket Dourado: prêmio especial concedido a clientes. Armazena código, cliente, status de resgate e validade.
- `events` — eventos da FLIZSTAR. Inclui flag `is_active` e `type` (padrão ou natal). Eventos de natal começam desativados.
- `discounts` — descontos aplicáveis a produtos ou eventos. Armazena produto alvo, percentual, código, validade e status.
- `customer_points` — pontos de fidelidade por cliente. Saldo acumulado e histórico.
- `gift_cards` — gift cards emitidos. Armazena código, valor, status de resgate, cliente e validade.
- `price_change_log` — log de alterações de preço com espera de 12 horas. Registra preço anterior, novo preço, status de aprovação (pending/approved/rejected) e horário de elegibilidade.

2. Modified Tables
- `products` — adiciona colunas `pending_price` (numeric, nullable) e `pending_price_eligible_at` (timestamptz, nullable) para suportar a espera de 12 horas na alteração de preços.

3. Security
- RLS habilitado em todas as novas tabelas.
- Clientes autenticados podem ler seus próprios pedidos, trocas, tickets, pontos e gift cards.
- Gerentes (private.is_manager()) podem ler e gerenciar todas as linhas administrativas.
- Anon pode apenas ler eventos ativos e descontos ativos (para exibição pública na loja).
- Todas as escritas administrativas exigem private.is_manager() no WITH CHECK.
- Insert de orders e trade_offers permitido para authenticated (cliente cria próprio pedido/troca).

4. Important Notes
- Eventos de Natal e Cassino de Natal começam desativados (is_active = false).
- A espera de 12 horas na alteração de preços é controlada por `pending_price_eligible_at`; o gerente aplica o preço pendente após 12 horas decorridas.
- Nenhuma funcionalidade de pagamento real é adicionada.
- Não altera produtos existentes nem dados atuais.
*/

-- Orders table
CREATE TABLE IF NOT EXISTS public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  product_name text NOT NULL DEFAULT '',
  customer_email text NOT NULL DEFAULT '',
  customer_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  nick text NOT NULL DEFAULT '',
  price numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid','delivered','cancelled','demo')),
  payment_method text NOT NULL DEFAULT 'pix',
  order_number text NOT NULL DEFAULT '',
  is_demo boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.orders TO authenticated;

DROP POLICY IF EXISTS "orders_select_own_or_manager" ON public.orders;
CREATE POLICY "orders_select_own_or_manager" ON public.orders
  FOR SELECT TO authenticated
  USING (customer_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "orders_insert_own" ON public.orders;
CREATE POLICY "orders_insert_own" ON public.orders
  FOR INSERT TO authenticated
  WITH CHECK (customer_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "orders_update_manager" ON public.orders;
CREATE POLICY "orders_update_manager" ON public.orders
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "orders_delete_manager" ON public.orders;
CREATE POLICY "orders_delete_manager" ON public.orders
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- Trade offers table
CREATE TABLE IF NOT EXISTS public.trade_offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  game text NOT NULL DEFAULT '',
  offer text NOT NULL DEFAULT '',
  looking text NOT NULL DEFAULT '',
  user_email text NOT NULL DEFAULT '',
  customer_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','matched','closed','reported','demo')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.trade_offers ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.trade_offers TO authenticated;
GRANT SELECT ON public.trade_offers TO anon;

DROP POLICY IF EXISTS "trades_select_all_or_manager" ON public.trade_offers;
CREATE POLICY "trades_select_all_or_manager" ON public.trade_offers
  FOR SELECT TO anon, authenticated
  USING (true);

DROP POLICY IF EXISTS "trades_insert_own" ON public.trade_offers;
CREATE POLICY "trades_insert_own" ON public.trade_offers
  FOR INSERT TO authenticated
  WITH CHECK (customer_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "trades_update_manager" ON public.trade_offers;
CREATE POLICY "trades_update_manager" ON public.trade_offers
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "trades_delete_manager" ON public.trade_offers;
CREATE POLICY "trades_delete_manager" ON public.trade_offers
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- Golden tickets table
CREATE TABLE IF NOT EXISTS public.golden_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  customer_email text NOT NULL DEFAULT '',
  customer_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'unused' CHECK (status IN ('unused','redeemed','expired','revoked')),
  prize text NOT NULL DEFAULT '',
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.golden_tickets ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.golden_tickets TO authenticated;

DROP POLICY IF EXISTS "tickets_select_own_or_manager" ON public.golden_tickets;
CREATE POLICY "tickets_select_own_or_manager" ON public.golden_tickets
  FOR SELECT TO authenticated
  USING (customer_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "tickets_insert_manager" ON public.golden_tickets;
CREATE POLICY "tickets_insert_manager" ON public.golden_tickets
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "tickets_update_manager" ON public.golden_tickets;
CREATE POLICY "tickets_update_manager" ON public.golden_tickets
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "tickets_delete_manager" ON public.golden_tickets;
CREATE POLICY "tickets_delete_manager" ON public.golden_tickets
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- Events table
CREATE TABLE IF NOT EXISTS public.events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  type text NOT NULL DEFAULT 'standard' CHECK (type IN ('standard','christmas','casino')),
  is_active boolean NOT NULL DEFAULT false,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.events ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.events TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.events TO authenticated;

DROP POLICY IF EXISTS "events_select_public" ON public.events;
CREATE POLICY "events_select_public" ON public.events
  FOR SELECT TO anon, authenticated
  USING (is_active = true OR private.is_manager());

DROP POLICY IF EXISTS "events_insert_manager" ON public.events;
CREATE POLICY "events_insert_manager" ON public.events
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "events_update_manager" ON public.events;
CREATE POLICY "events_update_manager" ON public.events
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "events_delete_manager" ON public.events;
CREATE POLICY "events_delete_manager" ON public.events
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- Discounts table
CREATE TABLE IF NOT EXISTS public.discounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid REFERENCES public.products(id) ON DELETE SET NULL,
  code text NOT NULL DEFAULT '',
  percent numeric(5,2) NOT NULL DEFAULT 0 CHECK (percent >= 0 AND percent <= 100),
  is_active boolean NOT NULL DEFAULT false,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.discounts ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON public.discounts TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.discounts TO authenticated;

DROP POLICY IF EXISTS "discounts_select_public" ON public.discounts;
CREATE POLICY "discounts_select_public" ON public.discounts
  FOR SELECT TO anon, authenticated
  USING (is_active = true OR private.is_manager());

DROP POLICY IF EXISTS "discounts_insert_manager" ON public.discounts;
CREATE POLICY "discounts_insert_manager" ON public.discounts
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "discounts_update_manager" ON public.discounts;
CREATE POLICY "discounts_update_manager" ON public.discounts
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "discounts_delete_manager" ON public.discounts;
CREATE POLICY "discounts_delete_manager" ON public.discounts
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- Customer points table
CREATE TABLE IF NOT EXISTS public.customer_points (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  customer_email text NOT NULL DEFAULT '',
  balance integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.customer_points ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.customer_points TO authenticated;

DROP POLICY IF EXISTS "points_select_own_or_manager" ON public.customer_points;
CREATE POLICY "points_select_own_or_manager" ON public.customer_points
  FOR SELECT TO authenticated
  USING (customer_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "points_insert_manager" ON public.customer_points;
CREATE POLICY "points_insert_manager" ON public.customer_points
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "points_update_manager" ON public.customer_points;
CREATE POLICY "points_update_manager" ON public.customer_points
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "points_delete_manager" ON public.customer_points;
CREATE POLICY "points_delete_manager" ON public.customer_points
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- Gift cards table
CREATE TABLE IF NOT EXISTS public.gift_cards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  value numeric(10,2) NOT NULL DEFAULT 0 CHECK (value >= 0),
  customer_email text NOT NULL DEFAULT '',
  customer_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  status text NOT NULL DEFAULT 'unused' CHECK (status IN ('unused','redeemed','expired','revoked')),
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.gift_cards ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.gift_cards TO authenticated;

DROP POLICY IF EXISTS "giftcards_select_own_or_manager" ON public.gift_cards;
CREATE POLICY "giftcards_select_own_or_manager" ON public.gift_cards
  FOR SELECT TO authenticated
  USING (customer_id = auth.uid() OR private.is_manager());

DROP POLICY IF EXISTS "giftcards_insert_manager" ON public.gift_cards;
CREATE POLICY "giftcards_insert_manager" ON public.gift_cards
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "giftcards_update_manager" ON public.gift_cards;
CREATE POLICY "giftcards_update_manager" ON public.gift_cards
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "giftcards_delete_manager" ON public.gift_cards;
CREATE POLICY "giftcards_delete_manager" ON public.gift_cards
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- Price change log table
CREATE TABLE IF NOT EXISTS public.price_change_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  product_name text NOT NULL DEFAULT '',
  old_price numeric(10,2) NOT NULL DEFAULT 0,
  new_price numeric(10,2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','applied')),
  eligible_at timestamptz NOT NULL DEFAULT (now() + interval '12 hours'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.price_change_log ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.price_change_log TO authenticated;

DROP POLICY IF EXISTS "pricechange_select_manager" ON public.price_change_log;
CREATE POLICY "pricechange_select_manager" ON public.price_change_log
  FOR SELECT TO authenticated
  USING (private.is_manager());

DROP POLICY IF EXISTS "pricechange_insert_manager" ON public.price_change_log;
CREATE POLICY "pricechange_insert_manager" ON public.price_change_log
  FOR INSERT TO authenticated
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "pricechange_update_manager" ON public.price_change_log;
CREATE POLICY "pricechange_update_manager" ON public.price_change_log
  FOR UPDATE TO authenticated
  USING (private.is_manager())
  WITH CHECK (private.is_manager());

DROP POLICY IF EXISTS "pricechange_delete_manager" ON public.price_change_log;
CREATE POLICY "pricechange_delete_manager" ON public.price_change_log
  FOR DELETE TO authenticated
  USING (private.is_manager());

-- Add pending price columns to products (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'products' AND column_name = 'pending_price') THEN
    ALTER TABLE public.products ADD COLUMN pending_price numeric(10,2);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_schema = 'public' AND table_name = 'products' AND column_name = 'pending_price_eligible_at') THEN
    ALTER TABLE public.products ADD COLUMN pending_price_eligible_at timestamptz;
  END IF;
END $$;

-- Seed Christmas/casino events as inactive
INSERT INTO public.events (name, description, type, is_active)
SELECT 'Evento de Natal', 'Evento sazonal de Natal — desativado até liberação oficial.', 'christmas', false
WHERE NOT EXISTS (SELECT 1 FROM public.events WHERE type = 'christmas');

INSERT INTO public.events (name, description, type, is_active)
SELECT 'Cassino de Natal', 'Cassino temático de Natal — desativado até liberação oficial.', 'casino', false
WHERE NOT EXISTS (SELECT 1 FROM public.events WHERE type = 'casino');

CREATE INDEX IF NOT EXISTS orders_status_idx ON public.orders (status, created_at);
CREATE INDEX IF NOT EXISTS trades_status_idx ON public.trade_offers (status, created_at);
CREATE INDEX IF NOT EXISTS events_active_idx ON public.events (is_active, type);
CREATE INDEX IF NOT EXISTS discounts_active_idx ON public.discounts (is_active);
CREATE INDEX IF NOT EXISTS pricechange_status_idx ON public.price_change_log (status, eligible_at);