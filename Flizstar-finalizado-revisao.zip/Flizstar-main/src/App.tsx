import { useEffect, useMemo, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { AdminPanel } from '@/components/AdminPanel';
import {
  ArrowRight,
  BadgeCheck,
  Bell,
  BookOpen,
  ChevronRight,
  CircleHelp,
  Clock3,
  LogOut,
  Pencil,
  Plus,
  Save,
  Trash2,
  Crown,
  Coins,
  Gamepad2,
  Gift,
  HeartHandshake,
  Instagram,
  Menu,
  MessageCircle,
  Package,
  Search,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  Star,
  Store,
  Ticket,
  Tag,
  TrendingUp,
  Trophy,
  Twitter,
  UserRound,
  Users,
  X,
  RefreshCw,
  AlertTriangle,
  Youtube,
  Zap,
} from 'lucide-react';

type Page = 'inicio' | 'loja' | 'trocas' | 'ranking' | 'vip' | 'minha-loja' | 'como-funciona' | 'regras' | 'suporte' | 'entrar' | 'admin' | 'minha-conta';
type UserRole = 'customer' | 'manager';
type Product = { id: string | number; name: string; game: string; category: string; description: string; price: number; color: string; icon: string; availability: string; delivery: string; image_url?: string };
type DbProduct = { id: string; name: string; description: string; game: string; category: string; image_url: string | null; price: number; is_active: boolean; is_demo: boolean; created_at: string; updated_at: string };
type Trade = { id: number; game: string; offer: string; looking: string; user: string; age: string; color: string };

const products: Product[] = [
  { id: 1, name: 'Nebula Bundle', game: 'Roblox', category: 'Itens', description: 'Pacote visual de demonstração com estética cósmica.', price: 29.9, color: 'cyan', icon: '✦', availability: 'Disponibilidade demonstrativa', delivery: 'Entrega manual após confirmação real' },
  { id: 2, name: 'Passe Estelar', game: 'Free Fire', category: 'Passe', description: 'Exemplo de passe premium para a temporada.', price: 39.9, color: 'pink', icon: '◆', availability: 'Disponibilidade demonstrativa', delivery: 'Entrega manual após confirmação real' },
  { id: 3, name: 'Gem Pack 500', game: 'Brawl Stars', category: 'Moeda', description: 'Quantidade ilustrativa de gemas para sua coleção.', price: 24.9, color: 'orange', icon: '✹', availability: 'Disponibilidade demonstrativa', delivery: 'Entrega manual após confirmação real' },
  { id: 4, name: 'Elite Crate', game: 'PUBG', category: 'Caixas', description: 'Caixa temática de demonstração para o inventário.', price: 49.9, color: 'gold', icon: '⬡', availability: 'Disponibilidade demonstrativa', delivery: 'Entrega manual após confirmação real' },
  { id: 5, name: 'Star Avatar', game: 'Roblox', category: 'Avatares', description: 'Avatar conceitual com acabamento neon.', price: 19.9, color: 'violet', icon: '★', availability: 'Disponibilidade demonstrativa', delivery: 'Entrega manual após confirmação real' },
  { id: 6, name: 'Skin Eclipse', game: 'Free Fire', category: 'Skins', description: 'Skin demonstrativa com detalhes luminosos.', price: 34.9, color: 'red', icon: '◈', availability: 'Disponibilidade demonstrativa', delivery: 'Entrega manual após confirmação real' },
  { id: 7, name: 'Mega Box', game: 'Brawl Stars', category: 'Caixas', description: 'Oferta visual de exemplo, sem entrega real.', price: 44.9, color: 'blue', icon: '▣', availability: 'Disponibilidade demonstrativa', delivery: 'Entrega manual após confirmação real' },
  { id: 8, name: 'Royale Pass', game: 'PUBG', category: 'Passe', description: 'Modelo de passe para apresentar a experiência.', price: 54.9, color: 'green', icon: '♢', availability: 'Disponibilidade demonstrativa', delivery: 'Entrega manual após confirmação real' },
];

function productVisual(game: string, category: string) {
  const visualByGame: Record<string, { color: string; icon: string }> = {
    Roblox: { color: 'cyan', icon: '✦' },
    'Free Fire': { color: 'pink', icon: '◆' },
    'Brawl Stars': { color: 'orange', icon: '✹' },
    PUBG: { color: 'gold', icon: '⬡' },
  };
  return visualByGame[game] ?? { color: 'violet', icon: category.slice(0, 1).toUpperCase() };
}

function fromDatabaseProduct(row: DbProduct): Product {
  const visual = productVisual(row.game, row.category);
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    game: row.game,
    category: row.category,
    image_url: row.image_url ?? undefined,
    price: Number(row.price),
    color: visual.color,
    icon: visual.icon,
    availability: row.is_active ? 'Ativo no catálogo' : 'Inativo no catálogo',
    delivery: 'Definida pelo gerente após a configuração da operação',
  };
}

const trades: Trade[] = [
  { id: 1, game: 'Roblox', offer: 'Pet lendário (exemplo)', looking: 'Item de evento antigo', user: 'LunarFox', age: 'há 12 min', color: 'violet' },
  { id: 2, game: 'Free Fire', offer: 'Skin Eclipse (exemplo)', looking: 'Skin temática de inverno', user: 'NoxPlayer', age: 'há 35 min', color: 'pink' },
  { id: 3, game: 'Brawl Stars', offer: 'Emote raro (exemplo)', looking: 'Visual de temporada', user: 'StarBrawler', age: 'há 1 h', color: 'orange' },
  { id: 4, game: 'PUBG', offer: 'Conjunto tático (exemplo)', looking: 'Caixa de evento', user: 'Vanta', age: 'há 2 h', color: 'cyan' },
];

const navItems: { id: Page; label: string; icon: typeof ShoppingBag }[] = [
  { id: 'inicio', label: 'Início', icon: Sparkles },
  { id: 'loja', label: 'Loja', icon: ShoppingBag },
  { id: 'trocas', label: 'Trocas', icon: HeartHandshake },
  { id: 'ranking', label: 'Rankings', icon: Trophy },
  { id: 'vip', label: 'VIP', icon: Crown },
];

function App() {
  const [page, setPage] = useState<Page>(window.location.pathname === '/admin' ? 'admin' : 'inicio');
  const [menuOpen, setMenuOpen] = useState(false);
  const [shopSearch, setShopSearch] = useState('');
  const [gameFilter, setGameFilter] = useState('Todos');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [orderProduct, setOrderProduct] = useState<Product | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [cart, setCart] = useState<Product[]>([]);
  const [notice, setNotice] = useState('');
  const [session, setSession] = useState<Session | null>(null);
  const [profileRole, setProfileRole] = useState<UserRole | null>(null);
  const [catalog, setCatalog] = useState<Product[]>(products);

  const refreshCatalog = async () => {
    const { data, error } = await supabase.from('products').select('*').eq('is_active', true).order('created_at', { ascending: false });
    if (!error && data) setCatalog((data as DbProduct[]).map(fromDatabaseProduct));
  };

  useEffect(() => {
    const closeOverlays = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      if (orderProduct) setOrderProduct(null);
      else if (selectedProduct) setSelectedProduct(null);
      else if (cartOpen) setCartOpen(false);
    };
    window.addEventListener('keydown', closeOverlays);
    return () => window.removeEventListener('keydown', closeOverlays);
  }, [cartOpen, orderProduct, selectedProduct]);

  useEffect(() => {
    let mounted = true;
    const loadSession = async () => {
      const { data } = await supabase.auth.getSession();
      if (!mounted) return;
      setSession(data.session);
      if (data.session?.user) {
        const { data: profile } = await supabase.from('profiles').select('role').eq('id', data.session.user.id).maybeSingle();
        if (mounted) setProfileRole((profile?.role as UserRole | undefined) ?? 'customer');
      }
    };
    void loadSession();
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      (async () => {
        if (!nextSession?.user) {
          setProfileRole(null);
          return;
        }
        const { data: profile } = await supabase.from('profiles').select('role').eq('id', nextSession.user.id).maybeSingle();
        setProfileRole((profile?.role as UserRole | undefined) ?? 'customer');
      })();
    });
    void refreshCatalog();
    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, []);

  useEffect(() => {
    const handlePopState = () => setPage(window.location.pathname === '/admin' ? 'admin' : 'inicio');
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const filteredProducts = useMemo(() => catalog.filter((product) => {
    const matchesText = `${product.name} ${product.game} ${product.description}`.toLowerCase().includes(shopSearch.toLowerCase());
    return matchesText && (gameFilter === 'Todos' || product.game === gameFilter);
  }), [catalog, shopSearch, gameFilter]);

  const navigate = (destination: Page) => {
    setPage(destination);
    setMenuOpen(false);
    if (destination === 'admin') window.history.pushState({}, '', '/admin');
    else if (window.location.pathname === '/admin') window.history.pushState({}, '', '/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const addToCart = (product: Product) => {
    setCart((current) => [...current, product]);
    setSelectedProduct(null);
    setNotice(`${product.name} foi adicionado ao carrinho demonstrativo.`);
    window.setTimeout(() => setNotice(''), 2800);
  };

  const startOrder = (product: Product) => {
    setSelectedProduct(null);
    setCartOpen(false);
    setOrderProduct(product);
  };

  return (
    <div className="app-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className="mobile-header">
        <Logo onClick={() => navigate('inicio')} /><button className="icon-button" onClick={() => setMenuOpen(!menuOpen)} aria-label="Abrir menu">{menuOpen ? <X /> : <Menu />}</button>
      </header>
      <div className={`mobile-menu ${menuOpen ? 'open' : ''}`}>
        {navItems.map((item) => <NavButton key={item.id} item={item} active={page === item.id} onClick={() => navigate(item.id)} />)}
        <NavButton item={{ id: 'como-funciona', label: 'Como funciona', icon: BookOpen }} active={page === 'como-funciona'} onClick={() => navigate('como-funciona')} />
        <NavButton item={{ id: 'suporte', label: 'Suporte', icon: CircleHelp }} active={page === 'suporte'} onClick={() => navigate('suporte')} />
        <NavButton item={{ id: 'ranking', label: 'Rankings', icon: Trophy }} active={page === 'ranking'} onClick={() => navigate('ranking')} />
        <NavButton item={{ id: 'vip', label: 'Área VIP', icon: Crown }} active={page === 'vip'} onClick={() => navigate('vip')} />
        <NavButton item={{ id: 'entrar', label: 'Entrar', icon: UserRound }} active={page === 'entrar'} onClick={() => navigate('entrar')} />
        {session && <NavButton item={{ id: 'minha-conta', label: 'Minha conta', icon: UserRound }} active={page === 'minha-conta'} onClick={() => navigate('minha-conta')} />}
        {session && profileRole === 'manager' && <NavButton item={{ id: 'admin', label: 'Painel administrativo', icon: ShieldCheck }} active={page === 'admin'} onClick={() => navigate('admin')} />}
      </div>
      <div className="layout">
        <aside className="sidebar panel">
          <Logo onClick={() => navigate('inicio')} />
          <div className="sidebar-divider" />
          <nav className="side-nav">{navItems.map((item) => <NavButton key={item.id} item={item} active={page === item.id} onClick={() => navigate(item.id)} />)}</nav>
          <div className="side-label">Explorar</div>
          <nav className="side-nav compact">
            <NavButton item={{ id: 'como-funciona', label: 'Como funciona', icon: BookOpen }} active={page === 'como-funciona'} onClick={() => navigate('como-funciona')} />
            <NavButton item={{ id: 'regras', label: 'Regras', icon: ShieldCheck }} active={page === 'regras'} onClick={() => navigate('regras')} />
            <NavButton item={{ id: 'suporte', label: 'Suporte', icon: CircleHelp }} active={page === 'suporte'} onClick={() => navigate('suporte')} />
            <NavButton item={{ id: 'ranking', label: 'Rankings', icon: Trophy }} active={page === 'ranking'} onClick={() => navigate('ranking')} />
            <NavButton item={{ id: 'vip', label: 'Área VIP', icon: Crown }} active={page === 'vip'} onClick={() => navigate('vip')} />
          </nav>
          <div className="side-label">Nossos canais</div>
          <div className="social-list"><Social icon={<Youtube />} label="YouTube" /><Social icon={<MessageCircle />} label="Discord" /><Social icon={<Instagram />} label="Instagram" /><Social icon={<Twitter />} label="X / Twitter" /></div>
          {session && <><div className="side-label">Minha conta</div><nav className="side-nav compact"><NavButton item={{ id: 'minha-conta', label: 'Minha conta', icon: UserRound }} active={page === 'minha-conta'} onClick={() => navigate('minha-conta')} /><NavButton item={{ id: 'minha-loja', label: 'Minha loja', icon: Store }} active={page === 'minha-loja'} onClick={() => navigate('minha-loja')} /></nav></>}
          {session && profileRole === 'manager' && <><div className="side-label">Administração</div><nav className="side-nav compact"><NavButton item={{ id: 'admin', label: 'Painel administrativo', icon: ShieldCheck }} active={page === 'admin'} onClick={() => navigate('admin')} /></nav></>}
          {session ? <button className="account-button" onClick={() => navigate('minha-conta')}><UserRound /><span><strong>Minha conta</strong><small>Perfil, pontos e inventário</small></span><ChevronRight /></button> : <button className="account-button" onClick={() => navigate('entrar')}><UserRound /><span><strong>Entrar</strong><small>Acesse sua conta</small></span><ChevronRight /></button>}
        </aside>

        <main className="content-area">
          {page === 'inicio' && <Home onNavigate={navigate} />}
          {page === 'loja' && <Shop products={filteredProducts} search={shopSearch} setSearch={setShopSearch} filter={gameFilter} setFilter={setGameFilter} onDetails={setSelectedProduct} onCart={() => setCartOpen(true)} cartCount={cart.length} />}
          {page === 'trocas' && <Trades onNotice={setNotice} />}
          {page === 'como-funciona' && <InfoPage type="how" onNavigate={navigate} />}
          {page === 'regras' && <InfoPage type="rules" onNavigate={navigate} />}
          {page === 'suporte' && <Support onNotice={setNotice} />}
          {page === 'entrar' && <Auth onNavigate={navigate} onNotice={setNotice} />}
          {page === 'ranking' && <RankingPage onNotice={setNotice} />}
          {page === 'vip' && <VipPage session={session} onNavigate={navigate} onNotice={setNotice} />}
          {page === 'minha-loja' && (session ? <CustomerShop onNavigate={navigate} onNotice={setNotice} /> : <Auth onNavigate={navigate} onNotice={setNotice} />)}
          {page === 'minha-conta' && (session ? <MyAccount onNavigate={navigate} onNotice={setNotice} /> : <Auth onNavigate={navigate} onNotice={setNotice} />)}
          {page === 'admin' && (session && profileRole === 'manager' ? <AdminPanel onNotice={setNotice} /> : <AdminAccess session={session} onNavigate={navigate} />)}
        </main>

        <aside className="right-rail">
          <div className="topline">SONHE <Sparkles /> JOGUE <Sparkles /> CONQUISTE</div>
          <div className="rail-card panel"><div className="rail-heading"><Star /><div><h3>Regras</h3><span>LEIA COM ATENÇÃO</span></div></div>{['Respeite todos os membros da comunidade.', 'Não use linguagem ofensiva.', 'Nunca compartilhe dados pessoais.', 'Negocie apenas pelos canais oficiais.'].map((rule, index) => <div className="rule" key={rule}><b>0{index + 1}</b><span>{rule}</span></div>)}<button className="rail-link" onClick={() => navigate('regras')}><ShieldCheck /><span><strong>Segurança em primeiro lugar</strong><small>Conheça nossas regras</small></span><ChevronRight /></button><button className="rail-link" onClick={() => navigate('suporte')}><CircleHelp /><span><strong>Precisa de ajuda?</strong><small>Fale com o suporte</small></span><ChevronRight /></button></div>
          <div className="rail-account panel" onClick={() => navigate('entrar')}><div className="avatar-ring"><UserRound /></div><span><strong>Entre na sua conta</strong><small>Acesse sua área e aproveite mais</small></span><ChevronRight /></div>
        </aside>
      </div>
      {selectedProduct && <ProductModal product={selectedProduct} onClose={() => setSelectedProduct(null)} onAdd={addToCart} onOrder={startOrder} />}
      {cartOpen && <CartDrawer items={cart} onClose={() => setCartOpen(false)} onOrder={startOrder} />}
      {orderProduct && <OrderFlow product={orderProduct} onClose={() => setOrderProduct(null)} onNotice={setNotice} />}
      {notice && <div className="toast"><BadgeCheck />{notice}</div>}
    </div>
  );
}

function Logo({ onClick }: { onClick: () => void }) { return <button className="logo" onClick={onClick}><span className="logo-star">✦</span><span>FLIZ<span>STAR</span><small>SITE OFICIAL</small></span></button>; }
function NavButton({ item, active, onClick }: { item: { id: Page; label: string; icon: typeof ShoppingBag }; active: boolean; onClick: () => void }) { const Icon = item.icon; return <button className={`nav-button ${active ? 'active' : ''}`} onClick={onClick}><Icon /><span>{item.label}</span><ChevronRight /></button>; }
function Social({ icon, label }: { icon: ReactNode; label: string }) { return <button className="social-row">{icon}<span>{label}</span><ChevronRight /></button>; }

function Home({ onNavigate }: { onNavigate: (page: Page) => void }) { return <div className="home-page"><div className="hero-top"><div className="eyebrow"><span /><span>UNIVERSO GAMER</span></div><h1>Seu universo gamer<br /><em>começa aqui.</em></h1><p>Uma comunidade para quem joga, troca e vive experiências inesquecíveis.</p><div className="hero-actions"><button className="primary-button" onClick={() => onNavigate('loja')}>Loja <ArrowRight /></button><button className="ghost-button" onClick={() => onNavigate('trocas')}>Ver trocas</button></div></div><div className="hero-art"><div className="halo" /><div className="star-orb">✦</div><img src="/images/file_00000000a354820e9aa2699a74c171e3.png" alt="Arte gamer em roxo da FLIZSTAR" /><div className="art-caption"><Sparkles /><span>JOGUE DO SEU JEITO</span></div></div><div className="feature-strip"><Feature icon={<Users />} title="Comunidade" text="Juntos somos mais fortes" /><Feature icon={<Star />} title="Confiança" text="Sempre com você" /><Feature icon={<Gamepad2 />} title="Diversão" text="É o nosso foco" /></div><div className="official-links"><span>LINKS OFICIAIS</span><div><a href="https://www.instagram.com/sabyy_xzz?dlrf=MTYyNW5lNzNvdWxmZg==" target="_blank" rel="noreferrer"><Instagram /> Instagram</a><a href="#discord" onClick={(event) => event.preventDefault()}><MessageCircle /> Discord</a><a href="#roblox" onClick={(event) => event.preventDefault()}><Gamepad2 /> Roblox</a></div></div><div className="manager-card"><div className="manager-avatar"><Sparkles /></div><div><span className="eyebrow purple">GERENTE OFICIAL FLIZSTAR</span><h3>Saby <small>— Gerente</small></h3><p><Instagram /> @sabyy_xzz · Acesse meu Instagram e me chama!</p></div><a href="https://www.instagram.com/sabyy_xzz?dlrf=MTYyNW5lNzNvdWxmZg==" target="_blank" rel="noreferrer" className="manager-button"><Instagram /> Instagram <ArrowRight /></a></div></div>; }
function Feature({ icon, title, text }: { icon: ReactNode; title: string; text: string }) { return <div className="feature"><div>{icon}</div><span><strong>{title}</strong><small>{text}</small></span></div>; }

function Shop({ products: visibleProducts, search, setSearch, filter, setFilter, onDetails, onCart, cartCount }: { products: Product[]; search: string; setSearch: (value: string) => void; filter: string; setFilter: (value: string) => void; onDetails: (product: Product) => void; onCart: () => void; cartCount: number }) { return <div className="inner-page"><PageHeading eyebrow="FLIZSTAR MARKET" title="Loja de itens" description="Uma vitrine demonstrativa para futuras experiências da comunidade." action={<button className="cart-button" onClick={onCart}><ShoppingCart /> Carrinho <b>{cartCount}</b></button>} /><div className="notice-banner"><Sparkles /><span>Todos os itens, preços e disponibilidades nesta tela são exemplos visuais. Nenhuma compra real é realizada.</span></div><div className="toolbar"><div className="search-box"><Search /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Buscar por item, jogo ou categoria" /></div><div className="filter-pills">{['Todos', 'Roblox', 'Free Fire', 'Brawl Stars', 'PUBG'].map((game) => <button className={filter === game ? 'selected' : ''} key={game} onClick={() => setFilter(game)}>{game}</button>)}</div></div>{visibleProducts.length === 0 ? <EmptyState text="Nenhum item combina com essa busca." /> : <div className="product-grid">{visibleProducts.map((product) => <ProductCard key={product.id} product={product} onDetails={onDetails} />)}</div>}</div>; }
function PageHeading({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: ReactNode }) { return <div className="page-heading"><div><div className="eyebrow"><span />{eyebrow}</div><h2>{title}</h2><p>{description}</p></div>{action}</div>; }
function ProductCard({ product, onDetails }: { product: Product; onDetails: (product: Product) => void }) { return <article className="product-card"><div className={`product-visual ${product.color}`}>{product.image_url ? <img src={product.image_url} alt={product.name} /> : <span>{product.icon}</span>}<small>EXEMPLO</small></div><div className="product-body"><div className="tag-row"><span>{product.game}</span><span>{product.category}</span></div><h3>{product.name}</h3><p>{product.description}</p><div className="product-footer"><strong>R$ {product.price.toFixed(2).replace('.', ',')}</strong><button onClick={() => onDetails(product)}>Ver detalhes <ArrowRight /></button></div></div></article>; }

function Trades({ onNotice }: { onNotice: (message: string) => void }) { const [query, setQuery] = useState(''); const [game, setGame] = useState('Todos'); const filtered = trades.filter((trade) => `${trade.offer} ${trade.looking} ${trade.user}`.toLowerCase().includes(query.toLowerCase()) && (game === 'Todos' || trade.game === game)); return <div className="inner-page"><PageHeading eyebrow="COMUNIDADE FLIZSTAR" title="Trocas seguras" description="Encontre possibilidades e converse com responsabilidade." action={<button className="primary-button" onClick={() => onNotice('O formulário de troca está disponível logo abaixo.')}>Propor uma troca <ArrowRight /></button>} /><div className="safety-card"><ShieldCheck /><div><strong>Nunca compartilhe senhas ou códigos de verificação.</strong><span>As ofertas abaixo são demonstrativas e não representam propostas reais de usuários.</span></div></div><div className="trade-tools"><div className="search-box"><Search /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar ofertas" /></div><select value={game} onChange={(event) => setGame(event.target.value)}>{['Todos', 'Roblox', 'Free Fire', 'Brawl Stars', 'PUBG'].map((item) => <option key={item}>{item}</option>)}</select></div><div className="trade-grid">{filtered.map((trade) => <article className="trade-card" key={trade.id}><div className={`trade-icon ${trade.color}`}><Gamepad2 /></div><div className="trade-meta"><span>{trade.game} · {trade.age}</span><strong>{trade.user}</strong></div><div className="trade-line"><small>OFERECE</small><p>{trade.offer}</p></div><div className="trade-line"><small>PROCURA</small><p>{trade.looking}</p></div><div className="trade-actions"><button onClick={() => onNotice('Interesse registrado apenas como demonstração.')}>Tenho interesse <ArrowRight /></button><button className="report" onClick={() => onNotice('Obrigado. O fluxo de denúncia é demonstrativo.')}>Denunciar</button></div></article>)}</div><div className="propose-card"><div><div className="eyebrow purple">SEU ESPAÇO</div><h3>Quer propor uma troca?</h3><p>Descreva o que você oferece e procura. Este formulário é apenas uma prévia da experiência.</p></div><button className="ghost-button" onClick={() => onNotice('Em uma próxima etapa, este formulário será conectado a uma conta verificada.')}>Criar proposta <ArrowRight /></button></div></div>; }

function InfoPage({ type, onNavigate }: { type: 'how' | 'rules'; onNavigate: (page: Page) => void }) { const how = type === 'how'; const items = how ? [{ icon: UserRound, title: 'Crie seu espaço', text: 'Entre na comunidade para acompanhar seus interesses e conversas.' }, { icon: Search, title: 'Explore com calma', text: 'Descubra itens e ofertas claramente identificados como demonstração.' }, { icon: HeartHandshake, title: 'Conecte-se', text: 'Use os canais oficiais e mantenha suas negociações seguras.' }] : [{ icon: ShieldCheck, title: 'Respeito sempre', text: 'Trate todos com educação. Discriminação, assédio e ofensas não são aceitos.' }, { icon: LockIcon, title: 'Proteja seus dados', text: 'Nunca compartilhe senha, código de autenticação ou informações pessoais.' }, { icon: Bell, title: 'Comunique problemas', text: 'Ao notar algo suspeito, pare a conversa e procure o suporte.' }]; return <div className="inner-page article-page"><PageHeading eyebrow={how ? 'GUIA FLIZSTAR' : 'CONVIVÊNCIA'} title={how ? 'Como funciona' : 'Regras da comunidade'} description={how ? 'Tudo o que você precisa para começar sua jornada com clareza.' : 'Um ambiente forte começa com atitudes responsáveis.'} /><div className="article-hero"><Sparkles /><h3>{how ? 'Jogue. Conecte. Evolua.' : 'Nossa comunidade, nossa responsabilidade.'}</h3><p>{how ? 'A FLIZSTAR reúne experiências gamer em um só universo, sempre com transparência e segurança.' : 'As regras existem para que a diversão continue sendo leve, segura e respeitosa para todos.'}</p></div><div className="info-steps">{items.map(({ icon: Icon, title, text }, index) => <div className="info-step" key={title}><span>0{index + 1}</span><Icon /><h3>{title}</h3><p>{text}</p></div>)}</div><button className="primary-button" onClick={() => onNavigate(how ? 'loja' : 'suporte')}>{how ? 'Explorar a loja' : 'Falar com suporte'} <ArrowRight /></button></div>; }
function LockIcon() { return <ShieldCheck />; }
function Support({ onNotice }: { onNotice: (message: string) => void }) { return <div className="inner-page support-page"><PageHeading eyebrow="CENTRAL FLIZSTAR" title="Como podemos ajudar?" description="Estamos aqui para manter sua experiência tranquila e segura." /><div className="support-grid"><button onClick={() => onNotice('Veja as regras completas na área Regras.')}><ShieldCheck /><strong>Regras e segurança</strong><span>Entenda como se proteger</span><ChevronRight /></button><button onClick={() => onNotice('As dúvidas frequentes estão sendo preparadas.')}><BookOpen /><strong>Dúvidas frequentes</strong><span>Respostas rápidas e claras</span><ChevronRight /></button><button onClick={() => onNotice('O contato com suporte é demonstrativo nesta primeira versão.')}><MessageCircle /><strong>Fale com a equipe</strong><span>Conte o que aconteceu</span><ChevronRight /></button></div><div className="contact-card"><Clock3 /><div><strong>Atendimento responsável</strong><p>Não envie senhas, códigos ou dados sensíveis. O suporte oficial nunca solicita essas informações.</p></div></div></div>; }
function Auth({ onNavigate, onNotice }: { onNavigate: (page: Page) => void; onNotice: (message: string) => void }) { const [email, setEmail] = useState(''); const [password, setPassword] = useState(''); const [mode, setMode] = useState<'login' | 'signup'>('login'); const [error, setError] = useState(''); const [loading, setLoading] = useState(false); const submit = async () => { setLoading(true); setError(''); const result = mode === 'login' ? await supabase.auth.signInWithPassword({ email, password }) : await supabase.auth.signUp({ email, password }); setLoading(false); if (result.error) { setError('Não foi possível concluir. Confira os dados e tente novamente.'); return; } if (mode === 'signup') { onNotice('Conta criada como cliente. O acesso de gerente é separado.'); setMode('login'); return; } onNotice('Login realizado com segurança.'); onNavigate('inicio'); }; return <div className="inner-page auth-page"><div className="auth-card"><div className="logo-mark">✦</div><div className="eyebrow purple">ÁREA DA COMUNIDADE</div><h2>{mode === 'login' ? 'Entre na FLIZSTAR' : 'Criar conta FLIZSTAR'}</h2><p>{mode === 'login' ? 'Acesse sua conta de cliente ou use as credenciais de gerente em /admin.' : 'Sua conta será criada como cliente. Gerentes são cadastrados separadamente.'}</p><label>E-mail<input value={email} onChange={(event) => setEmail(event.target.value)} placeholder="voce@email.com" type="email" autoComplete="email" /></label><label>Senha<input value={password} onChange={(event) => setPassword(event.target.value)} placeholder="••••••••" type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'} /></label>{error && <div className="auth-error">{error}</div>}<button className="primary-button" disabled={loading || !email || !password} onClick={submit}>{loading ? 'Aguarde...' : mode === 'login' ? 'Continuar' : 'Criar conta'} <ArrowRight /></button><button className="text-button" onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }}>{mode === 'login' ? 'Ainda não tem conta? Criar conta' : 'Já tenho uma conta'}</button></div></div>; }
function ProductModal({ product, onClose, onAdd, onOrder }: { product: Product; onClose: () => void; onAdd: (product: Product) => void; onOrder: (product: Product) => void }) { return <div className="modal-backdrop" onClick={onClose}><div className="modal-card product-detail-modal" onClick={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="product-detail-title"><button className="modal-close" onClick={onClose} aria-label="Fechar detalhes"><X /></button><div className={`product-visual large ${product.color}`}>{product.image_url ? <img src={product.image_url} alt={product.name} /> : <span>{product.icon}</span>}<small>ITEM DEMONSTRATIVO</small></div><div className="tag-row"><span>{product.game}</span><span>{product.category}</span></div><h2 id="product-detail-title">{product.name}</h2><p>{product.description}</p><div className="detail-list"><div><small>DISPONIBILIDADE</small><strong>{product.availability}</strong></div><div><small>ENTREGA</small><strong>{product.delivery}</strong></div><div><small>IDENTIFICAÇÃO</small><strong>Nick no jogo poderá ser solicitado no pedido</strong></div></div><div className="modal-price">R$ {product.price.toFixed(2).replace('.', ',')} <small>valor de exemplo</small></div><div className="modal-actions"><button className="ghost-button" onClick={() => onAdd(product)}>Adicionar ao carrinho <ShoppingCart /></button><button className="primary-button" onClick={() => onOrder(product)}>Criar pedido <ArrowRight /></button></div><p className="modal-disclaimer">Esta tela é demonstrativa. Não há venda, estoque ou pagamento confirmado.</p></div></div>; }
function CartDrawer({ items, onClose, onOrder }: { items: Product[]; onClose: () => void; onOrder: (product: Product) => void }) { const total = items.reduce((sum, item) => sum + item.price, 0); return <div className="drawer-backdrop" onClick={onClose}><aside className="cart-drawer" onClick={(event) => event.stopPropagation()}><div className="drawer-heading"><div><div className="eyebrow purple">SUA SELEÇÃO</div><h2>Carrinho</h2></div><button className="icon-button" onClick={onClose} aria-label="Fechar carrinho"><X /></button></div>{items.length === 0 ? <EmptyState text="Seu carrinho demonstrativo está vazio." /> : <>{items.map((item, index) => <div className="cart-item" key={`${item.id}-${index}`}><div className={`mini-product ${item.color}`}>{item.icon}</div><span><strong>{item.name}</strong><small>{item.game}</small></span><b>R$ {item.price.toFixed(2).replace('.', ',')}</b></div>)}<div className="cart-total"><span>Total demonstrativo</span><strong>R$ {total.toFixed(2).replace('.', ',')}</strong></div><p className="cart-note">Nenhum pedido real será enviado ou cobrado.</p><button className="primary-button full" onClick={() => onOrder(items[0])}>Criar pedido demonstrativo <ArrowRight /></button></>}</aside></div>; }

function OrderFlow({ product, onClose, onNotice }: { product: Product; onClose: () => void; onNotice: (message: string) => void }) { const [nick, setNick] = useState(''); const [email, setEmail] = useState(''); const [payment, setPayment] = useState('pix'); const [orderNumber, setOrderNumber] = useState(''); const canSubmit = nick.trim().length > 0 && email.trim().length > 0; const createOrder = () => { if (!canSubmit) return; setOrderNumber(`FLZ-DEMO-${String(product.id).padStart(2, '0')}-${Math.floor(1000 + Math.random() * 9000)}`); onNotice('Pedido demonstrativo criado sem cobrança.'); }; return <div className="modal-backdrop order-backdrop" onClick={onClose}><div className="order-card" onClick={(event) => event.stopPropagation()} role="dialog" aria-modal="true" aria-labelledby="order-title"><button className="modal-close" onClick={onClose} aria-label="Fechar criação de pedido"><X /></button>{orderNumber ? <OrderConfirmation product={product} orderNumber={orderNumber} nick={nick} email={email} onClose={onClose} /> : <><div className="eyebrow purple">FLIZSTAR CHECKOUT · DEMONSTRAÇÃO</div><h2 id="order-title">Criar pedido</h2><p className="order-intro">Confira os dados antes de gerar um pedido de exemplo. Nenhuma cobrança ou entrega será realizada.</p><div className="order-product"><div className={`mini-product ${product.color}`}>{product.icon}</div><div><strong>{product.name}</strong><small>{product.game} · {product.category}</small></div><b>R$ {product.price.toFixed(2).replace('.', ',')}</b></div><div className="order-form"><label>Nick no jogo <span>necessário para este item</span><input value={nick} onChange={(event) => setNick(event.target.value)} placeholder={`Seu nick no ${product.game}`} /></label><label>E-mail para identificar o pedido<input value={email} onChange={(event) => setEmail(event.target.value)} type="email" placeholder="voce@email.com" /></label><p className="login-note"><ShieldCheck /> Não solicitamos senha de contas de jogos. Um login real da FLIZSTAR só será necessário quando a conta estiver conectada.</p><div className="payment-label">Método de pagamento</div><div className="payment-options"><button className={payment === 'pix' ? 'payment-option selected' : 'payment-option'} onClick={() => setPayment('pix')}><span>PIX</span><small>Indisponível até integrar um provedor</small></button><button className="payment-option unavailable" disabled><span>Cartão</span><small>Indisponível</small></button></div><div className="pix-placeholder"><ShoppingCart /><div><strong>QR Code Pix aparecerá aqui</strong><span>Somente após a integração com um provedor real. Não há QR Code nesta demonstração.</span></div></div><button className="primary-button full" disabled={!canSubmit} onClick={createOrder}>Gerar pedido demonstrativo <ArrowRight /></button>{!canSubmit && <small className="form-hint">Informe o nick e o e-mail para gerar o resumo demonstrativo.</small>}</div></>}</div></div>; }
function OrderConfirmation({ product, orderNumber, nick, email, onClose }: { product: Product; orderNumber: string; nick: string; email: string; onClose: () => void }) { return <div className="order-confirmation"><div className="confirmation-icon"><BadgeCheck /></div><div className="eyebrow purple">RESUMO DO PEDIDO</div><h2>Pedido criado</h2><p className="confirmation-warning">Este é um pedido demonstrativo. O pagamento não foi iniciado nem confirmado.</p><div className="confirmation-summary"><div><small>NÚMERO DO PEDIDO</small><strong>{orderNumber}</strong></div><div><small>PRODUTO</small><strong>{product.name}</strong></div><div><small>NICK NO JOGO</small><strong>{nick}</strong></div><div><small>IDENTIFICAÇÃO</small><strong>{email}</strong></div><div><small>VALOR</small><strong>R$ {product.price.toFixed(2).replace('.', ',')}</strong></div><div><small>STATUS DO PAGAMENTO</small><strong className="pending-status">Aguardando integração</strong></div></div><div className="pix-placeholder"><ShoppingCart /><div><strong>QR Code Pix não disponível</strong><span>O provedor de pagamentos ainda não foi configurado, então nada pode ser pago aqui.</span></div></div><button className="primary-button full" onClick={onClose}>Voltar para a Loja <ArrowRight /></button></div>; }
function AdminAccess({ session, onNavigate }: { session: Session | null; onNavigate: (page: Page) => void }) { const signOut = async () => { await supabase.auth.signOut(); }; return <div className="inner-page auth-page"><div className="auth-card admin-access-card"><div className="logo-mark"><ShieldCheck /></div><div className="eyebrow purple">ÁREA RESTRITA</div><h2>{session ? 'Acesso de gerente necessário' : 'Painel administrativo'}</h2><p>{session ? 'Esta conta está identificada como cliente e não possui permissões para gerenciar a Loja.' : 'Entre com uma conta de gerente da FLIZSTAR para acessar este espaço.'}</p>{session ? <button className="ghost-button full" onClick={signOut}><LogOut /> Sair desta conta</button> : <button className="primary-button full" onClick={() => onNavigate('entrar')}>Entrar na FLIZSTAR <ArrowRight /></button>}<small className="admin-note">As permissões são conferidas no banco de dados, não apenas nesta tela.</small></div></div>; }

type MyProfile = { id: string; email: string; role: string; created_at: string; nick?: string | null; bio?: string | null; level?: number; xp?: number; is_banned?: boolean };
type MyOrder = { id: string; product_name: string; price: number; status: string; order_number: string; created_at: string };
type MyInventoryItem = { id: string; product_name: string; source: string; granted_at: string };
type MyGiftCard = { id: string; code: string; value: number; status: string; created_at: string };
type MyTicket = { id: string; code: string; prize: string; status: string; created_at: string };
type MyPoints = { id: string; balance: number };
type MyBenefit = { id: string; benefit: string; source: string; status: string; details: string | null };
type MyRanking = { globalRank: number | null; investorRank: number | null; totalSpent: number };

function useRankingBenefits(userId: string | null) {
  const [benefits, setBenefits] = useState<MyBenefit[]>([]);
  const [ranking, setRanking] = useState<MyRanking>({ globalRank: null, investorRank: null, totalSpent: 0 });
  useEffect(() => {
    if (!userId) return;
    void (async () => {
      const [benefitsRes, globalRes, investorRes] = await Promise.all([
        supabase.from('benefit_history').select('id, benefit, source, status, details').eq('customer_id', userId).order('created_at', { ascending: false }),
        supabase.from('top_global_ranking').select('rank_position').eq('customer_id', userId).maybeSingle(),
        supabase.from('top_investidores_standings').select('rank_position, total_spent').eq('customer_id', userId).maybeSingle(),
      ]);
      if (benefitsRes.data) setBenefits(benefitsRes.data as MyBenefit[]);
      if (globalRes.data) setRanking((r) => ({ ...r, globalRank: (globalRes.data as { rank_position: number }).rank_position }));
      if (investorRes.data) setRanking((r) => ({ ...r, investorRank: (investorRes.data as { rank_position: number; total_spent: number }).rank_position, totalSpent: Number((investorRes.data as { total_spent: number }).total_spent) }));
    })();
  }, [userId]);
  const activeBenefits = benefits.filter((b) => b.status === 'granted');
  return { benefits: activeBenefits, ranking };
}

function BenefitBadges({ benefits, ranking }: { benefits: MyBenefit[]; ranking: MyRanking }) {
  const items: { label: string; type: string; permanent: boolean }[] = [];
  const hasBenefit = (name: string) => benefits.some((b) => b.benefit === name);
  if (ranking.globalRank === 1) items.push({ label: 'TOP 1 GLOBAL', type: 'top1-global', permanent: false });
  if (ranking.globalRank === 2) items.push({ label: 'TOP 2 GLOBAL', type: 'top2-global', permanent: false });
  if (ranking.investorRank === 5) items.push({ label: 'GASTA MUITO', type: 'gasta-muito', permanent: false });
  if (ranking.investorRank === 1) items.push({ label: 'TOP 1 INVESTIDOR', type: 'top1-investidor', permanent: false });
  if (ranking.investorRank === 2) items.push({ label: 'AMALDIÇOADO', type: 'amaldicoado', permanent: false });
  for (const b of benefits) {
    if (b.benefit === 'seal:permanent' && !items.some((i) => i.label === b.details)) items.push({ label: b.details ?? b.benefit, type: 'permanent', permanent: true });
  }
  if (items.length === 0) return null;
  return <div className="benefits-row">{items.map((item) => <span key={item.label} className={`benefit-item ${item.permanent ? 'permanent' : 'positional'}`}>{item.permanent ? <BadgeCheck /> : <Star />}{item.label}</span>)}</div>;
}

function MyAccount({ onNavigate, onNotice }: { onNavigate: (page: Page) => void; onNotice: (message: string) => void }) {
  const [profile, setProfile] = useState<MyProfile | null>(null);
  const [orders, setOrders] = useState<MyOrder[]>([]);
  const [inventory, setInventory] = useState<MyInventoryItem[]>([]);
  const [giftCards, setGiftCards] = useState<MyGiftCard[]>([]);
  const [tickets, setTickets] = useState<MyTicket[]>([]);
  const [points, setPoints] = useState<MyPoints | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [editingNick, setEditingNick] = useState(false);
  const [nickValue, setNickValue] = useState('');
  const { benefits, ranking } = useRankingBenefits(userId);

  useEffect(() => {
    void (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      setUserId(user.id);
      const [profileRes, ordersRes, invRes, giftRes, ticketRes, pointsRes] = await Promise.all([
        supabase.from('profiles').select('*').eq('id', user.id).maybeSingle(),
        supabase.from('orders').select('id, product_name, price, status, order_number, created_at').eq('customer_id', user.id).order('created_at', { ascending: false }),
        supabase.from('customer_inventory').select('id, product_name, source, granted_at').eq('customer_id', user.id).order('granted_at', { ascending: false }),
        supabase.from('gift_cards').select('id, code, value, status, created_at').eq('customer_id', user.id).order('created_at', { ascending: false }),
        supabase.from('golden_tickets').select('id, code, prize, status, created_at').eq('customer_id', user.id).order('created_at', { ascending: false }),
        supabase.from('customer_points').select('id, balance').eq('customer_id', user.id).maybeSingle(),
      ]);
      if (profileRes.data) setProfile(profileRes.data as MyProfile);
      if (ordersRes.data) setOrders(ordersRes.data as MyOrder[]);
      if (invRes.data) setInventory(invRes.data as MyInventoryItem[]);
      if (giftRes.data) setGiftCards(giftRes.data as MyGiftCard[]);
      if (ticketRes.data) setTickets(ticketRes.data as MyTicket[]);
      if (pointsRes.data) setPoints(pointsRes.data as MyPoints);
      setLoading(false);
    })();
  }, []);

  const signOut = async () => { await supabase.auth.signOut(); onNotice('Você saiu da sua conta.'); onNavigate('inicio'); };

  const saveNick = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from('profiles').update({ nick: nickValue.trim() || null, updated_at: new Date().toISOString() }).eq('id', user.id);
    if (error) { onNotice('Não foi possível salvar o apelido.'); return; }
    setProfile({ ...profile!,id: profile!.id, email: profile!.email, role: profile!.role, created_at: profile!.created_at, nick: nickValue.trim() || null });
    setEditingNick(false);
    onNotice('Apelido atualizado.');
  };

  if (loading) return <div className="inner-page"><p className="admin-empty-inline">Carregando seu perfil...</p></div>;
  if (!profile) return <div className="inner-page auth-page"><div className="auth-card"><h2>Faça login para ver sua conta</h2><button className="primary-button full" onClick={() => onNavigate('entrar')}>Entrar <ArrowRight /></button></div></div>;

  const level = profile.level ?? 1;
  const xp = profile.xp ?? 0;
  const xpForNext = level * 1000;
  const xpProgress = Math.min(100, (xp / xpForNext) * 100);
  const fmtDate = (v: string) => new Date(v).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
  const fmtBRL = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`;
  const avatarFrameClass = ranking.globalRank === 1 ? 'framed-top1-global' : ranking.globalRank === 2 ? 'framed-top2-global' : ranking.investorRank === 1 || ranking.investorRank === 3 || ranking.investorRank === 4 ? 'framed-top4-investidor' : '';
  const bannerClass = ranking.globalRank === 1 ? 'top1-global' : ranking.globalRank === 2 ? 'top2-global' : ranking.investorRank === 1 || ranking.investorRank === 3 || ranking.investorRank === 4 ? 'top4-investidor' : '';
  const animClass = ranking.globalRank === 1 ? 'profile-animated-top1' : ranking.investorRank === 3 ? 'profile-animated-top3' : '';

  return (
    <div className={`inner-page my-account-page ${animClass}`}>
      <PageHeading eyebrow="SUA CONTA FLIZSTAR" title="Minha conta" description="Veja seu perfil, nível, pontos, inventário, compras e presentes." action={<button className="ghost-button" onClick={signOut}><LogOut /> Sair</button>} />
      {bannerClass && <div className={`profile-banner ${bannerClass}`} />}
      <div className="customer-profile-card">
        <div className="customer-profile-header">
          <div className={`customer-avatar ${avatarFrameClass}`}>{ranking.globalRank === 1 ? <Crown className="profile-crown-glow" /> : <UserRound />}</div>
          <div className="customer-profile-info">
            <div className="customer-name-row">
              <h3>{profile.nick || profile.email}</h3>
              {ranking.globalRank === 1 && <em className="nick-position-badge top1-global">TOP 1</em>}
              {ranking.globalRank === 2 && <em className="nick-position-badge top2-global">TOP 2</em>}
              {ranking.investorRank === 1 && <em className="nick-position-badge top1-investidor">INVESTIDOR #1</em>}
              {ranking.investorRank === 2 && <em className="nick-position-badge top2-investidor">AMALDIÇOADO</em>}
              {profile.is_banned && <em className="status-badge banned">Banido</em>}
              <em className={`role-badge ${profile.role}`}>{profile.role === 'manager' ? 'Gerente' : 'Cliente'}</em>
            </div>
            <small>{profile.email}</small>
            <small>Cadastro: {fmtDate(profile.created_at)}</small>
            <BenefitBadges benefits={benefits} ranking={ranking} />
            {editingNick ? (
              <div className="my-nick-edit">
                <input value={nickValue} onChange={(e) => setNickValue(e.target.value)} placeholder="Seu apelido" maxLength={30} />
                <button className="primary-button" onClick={saveNick}><BadgeCheck /> Salvar</button>
                <button className="ghost-button" onClick={() => setEditingNick(false)}>Cancelar</button>
              </div>
            ) : (
              <button className="text-button" style={{ margin: '6px 0 0', textAlign: 'left' }} onClick={() => { setNickValue(profile.nick ?? ''); setEditingNick(true); }}><Pencil /> {profile.nick ? 'Alterar apelido' : 'Definir apelido'}</button>
            )}
          </div>
        </div>
        <div className="customer-level-bar">
          <div className="customer-level-stats">
            <span><Zap /> Nível {level}</span>
            <small>{xp} / {xpForNext} XP</small>
          </div>
          <div className="xp-bar-track"><div className="xp-bar-fill" style={{ width: `${xpProgress}%` }} /></div>
        </div>
        <div className="customer-quick-stats">
          <div><Coins /> <b>{points?.balance ?? 0}</b><small>pontos</small></div>
          <div><ShoppingBag /> <b>{orders.length}</b><small>compras</small></div>
          <div><Package /> <b>{inventory.length}</b><small>inventário</small></div>
          <div><Gift /> <b>{giftCards.length}</b><small>gift cards</small></div>
          <div><Ticket /> <b>{tickets.length}</b><small>tickets</small></div>
          {ranking.globalRank && ranking.globalRank <= 10 && <div><Trophy /> <b>#{ranking.globalRank}</b><small>global</small></div>}
          {ranking.investorRank && <div><TrendingUp /> <b>#{ranking.investorRank}</b><small>investidor</small></div>}
        </div>
      </div>

      <div className="customer-sections-grid">
        <div className="customer-section-card">
          <h4><ShoppingBag /> Minhas compras</h4>
          {orders.length === 0 ? <p className="admin-empty-inline">Nenhuma compra registrada ainda.</p> : (
            <div className="customer-mini-list">
              {orders.map((o) => (
                <div className="customer-mini-row" key={o.id}>
                  <span>{o.product_name || '—'}</span>
                  <b>{fmtBRL(Number(o.price))}</b>
                  <em className={`status-badge ${o.status}`}>{o.status}</em>
                  <small>{fmtDate(o.created_at)}</small>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="customer-section-card">
          <h4><Package /> Meu inventário</h4>
          {inventory.length === 0 ? <p className="admin-empty-inline">Seu inventário está vazio.</p> : (
            <div className="customer-mini-list">
              {inventory.map((item) => (
                <div className="customer-mini-row" key={item.id}>
                  <span>{item.product_name}</span>
                  <em className={`source-badge ${item.source}`}>{item.source}</em>
                  <small>{fmtDate(item.granted_at)}</small>
                  <small />
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="customer-section-card">
          <h4><Gift /> Meus presentes</h4>
          {giftCards.length === 0 && tickets.length === 0 ? <p className="admin-empty-inline">Nenhum presente ou ticket recebido.</p> : (
            <div className="customer-mini-list">
              {giftCards.map((g) => (
                <div className="customer-mini-row" key={g.id}>
                  <span className="mono">{g.code}</span>
                  <b>{fmtBRL(Number(g.value))}</b>
                  <em className={`status-badge ${g.status}`}>{g.status}</em>
                  <small>{fmtDate(g.created_at)}</small>
                </div>
              ))}
              {tickets.map((t) => (
                <div className="customer-mini-row" key={t.id}>
                  <span className="mono">{t.code}</span>
                  <small>{t.prize}</small>
                  <em className={`status-badge ${t.status}`}>{t.status}</em>
                  <small>{fmtDate(t.created_at)}</small>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="customer-section-card">
          <h4><TrendingUp /> Resumo</h4>
          <div className="my-summary-list">
            <div><span>Pontos acumulados</span><b>{points?.balance ?? 0}</b></div>
            <div><span>Nível atual</span><b>{level}</b></div>
            <div><span>Experiência</span><b>{xp} XP</b></div>
            <div><span>Total de compras</span><b>{orders.length}</b></div>
            <div><span>Itens no inventário</span><b>{inventory.length}</b></div>
            <div><span>Gift cards</span><b>{giftCards.length}</b></div>
            <div><span>Tickets dourados</span><b>{tickets.length}</b></div>
            {ranking.globalRank && <div><span>Posição no Top Global</span><b>#{ranking.globalRank}</b></div>}
            {ranking.investorRank && <div><span>Posição no Top Investidores</span><b>#{ranking.investorRank}</b></div>}
            {ranking.totalSpent > 0 && <div><span>Total investido</span><b>{fmtBRL(ranking.totalSpent)}</b></div>}
          </div>
          {ranking.investorRank === 1 && <button className="primary-button" style={{ marginTop: 12 }} onClick={() => onNavigate('minha-loja')}><Store /> Gerenciar minha loja <ArrowRight /></button>}
        </div>
      </div>
    </div>
  );
}

type GlobalRankEntry = { customer_id: string; email: string; nick: string | null; level: number; xp: number; points_balance: number; rank_position: number };
type InvestorRankEntry = { id: string; customer_id: string; customer_email: string; total_spent: number; rank_position: number };
type PeriodInfo = { id: string; starts_at: string; ends_at: string; status: string };

function VipPage({ session, onNavigate, onNotice }: { session: Session | null; onNavigate: (page: Page) => void; onNotice: (message: string) => void }) {
  const benefits = [
    { icon: Star, title: 'Perfil personalizado', text: 'Destaque visual para seu perfil, com moldura, nome e efeitos VIP quando disponíveis.' },
    { icon: Coins, title: 'Benefícios de pontos e XP', text: 'Benefícios de progressão conforme as regras VIP e a elegibilidade de cada atividade.' },
    { icon: Tag, title: 'Código de desconto', text: 'Possibilidade de criar um código de 50% para até 10 pessoas, conforme as regras da FLIZSTAR.' },
    { icon: Gift, title: 'Presente VIP', text: 'Presente especial associado a um pagamento confirmado, sem duplicar a mesma confirmação.' },
    { icon: Store, title: 'Acesso à Loja ADM', text: 'Acesso enquanto os requisitos VIP estiverem ativos; itens já adquiridos continuam pertencendo ao cliente.' },
    { icon: Trophy, title: 'Destaque na comunidade', text: 'Benefícios e selos elegíveis aparecem de acordo com as regras e a posição atual nos rankings.' },
  ];
  return <div className="inner-page vip-page">
    <PageHeading eyebrow="EXPERIÊNCIA EXCLUSIVA" title="Área VIP" description="Conheça os benefícios planejados para membros VIP da FLIZSTAR." />
    <section style={{ position: 'relative', overflow: 'hidden', borderRadius: 24, padding: 'clamp(24px, 5vw, 42px)', marginBottom: 22, border: '1px solid rgba(245,190,70,.35)', background: 'radial-gradient(circle at 85% 10%, rgba(245,190,70,.19), transparent 35%), linear-gradient(135deg, #201a30, #10111c 72%)' }}>
      <div style={{ display: 'inline-flex', alignItems: 'center', gap: 8, color: '#f5c45e', fontSize: 12, letterSpacing: 2, fontWeight: 800 }}><Crown size={17} /> FLIZSTAR VIP</div>
      <h3 style={{ fontSize: 'clamp(28px, 5vw, 44px)', lineHeight: 1.1, margin: '16px 0 12px', color: '#fff' }}>Sua jornada, em outro nível.</h3>
      <p style={{ maxWidth: 620, color: '#c6c3d1', lineHeight: 1.7, marginBottom: 22 }}>Uma área dedicada aos benefícios VIP, personalização e acesso a experiências exclusivas. Os benefícios dependem de assinatura ativa e das regras aplicáveis.</p>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
        <button className="primary-button" onClick={() => session ? onNotice('A contratação VIP ainda precisa de um fluxo de pagamento confirmado. Nenhuma cobrança foi realizada.') : onNavigate('entrar')}>{session ? 'Consultar ativação VIP' : 'Entrar para continuar'} <ArrowRight size={17} /></button>
        <button className="ghost-button" onClick={() => onNavigate('regras')}>Ver regras</button>
      </div>
      <p style={{ fontSize: 12, color: '#aaa5b9', marginTop: 16 }}>Transparência: esta tela apresenta os benefícios previstos. A assinatura e os pagamentos ainda não são ativados por este botão.</p>
    </section>
    <div className="info-steps" style={{ gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 220px), 1fr))' }}>
      {benefits.map(({ icon: Icon, title, text }) => <article className="info-step" key={title} style={{ textAlign: 'left' }}><Icon size={25} style={{ color: '#e9bd59' }} /><h3>{title}</h3><p>{text}</p></article>)}
    </div>
  </div>;
}

function RankingPage({ onNotice }: { onNotice: (message: string) => void }) {
  const [globalRank, setGlobalRank] = useState<GlobalRankEntry[]>([]);
  const [investorRank, setInvestorRank] = useState<InvestorRankEntry[]>([]);
  const [period, setPeriod] = useState<PeriodInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const loadRankings = async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const [globalRes, investorRes, periodRes] = await Promise.all([
        supabase.from('top_global_ranking').select('customer_id, email, nick, level, xp, points_balance, rank_position').order('rank_position', { ascending: true }).limit(10),
        supabase.from('top_investidores_standings').select('id, customer_id, customer_email, total_spent, rank_position').order('rank_position', { ascending: true }).limit(5),
        supabase.from('ranking_periods').select('id, starts_at, ends_at, status').eq('kind', 'top_investidores').eq('status', 'active').order('starts_at', { ascending: false }).limit(1).maybeSingle(),
      ]);
      if (globalRes.error || investorRes.error || periodRes.error) {
        setLoadError('Não foi possível carregar todos os rankings. Verifique as migrações e permissões do Supabase.');
      }
      if (globalRes.data) setGlobalRank((globalRes.data as GlobalRankEntry[]).sort((a, b) => a.rank_position - b.rank_position));
      if (investorRes.data) setInvestorRank((investorRes.data as InvestorRankEntry[]).sort((a, b) => a.rank_position - b.rank_position));
      if (periodRes.data) setPeriod(periodRes.data as PeriodInfo);
    } catch {
      setLoadError('Falha de conexão ao carregar os rankings. Tente atualizar novamente.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { void loadRankings(); }, []);

  const fmtBRL = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`;
  const fmtDate = (v: string) => new Date(v).toLocaleDateString('pt-BR');

  if (loading && globalRank.length === 0 && investorRank.length === 0) return <div className="inner-page"><p className="admin-empty-inline">Carregando rankings...</p></div>;

  return (
    <div className="inner-page ranking-page">
      <PageHeading eyebrow="RANKINGS FLIZSTAR" title="Top Global" description="Os 10 melhores da comunidade por saldo atual de pontos." action={<button className="ghost-button" onClick={() => void loadRankings()} disabled={loading}><RefreshCw size={16} /> {loading ? 'Atualizando...' : 'Atualizar'}</button>} />
      {loadError && <div role="alert" className="notice-banner" style={{ marginBottom: 18 }}><AlertTriangle /><span>{loadError}</span></div>}

      <div className="ranking-section">
        <div className="ranking-section-head">
          <div className="ranking-icon"><Trophy /></div>
          <div>
            <div className="eyebrow purple"><span />TOP GLOBAL</div>
            <h3>Top 10 por pontos</h3>
            <p>Atualizado em tempo real pelo saldo de pontos</p>
          </div>
        </div>
        {globalRank.length === 0 ? <p className="admin-empty-inline">Nenhum cliente no ranking ainda.</p> : (
          <div className="ranking-list">
            {globalRank.map((entry) => {
              const pos = entry.rank_position;
              const rowClass = pos === 1 ? 'top-1' : pos === 2 ? 'top-2' : pos === 3 ? 'top-3' : '';
              const sealClass = pos === 1 ? 'seal-top1-global' : pos === 2 ? 'seal-top2-global' : '';
              return (
                <div className={`ranking-row ${rowClass}`} key={entry.customer_id}>
                  <div className="ranking-position">{pos}</div>
                  <div className="ranking-user">
                    <div className="ranking-user-avatar">{pos === 1 ? <Crown /> : <UserRound />}</div>
                    <div className="ranking-user-info">
                      <strong>{entry.nick || entry.email}</strong>
                      <small>Nível {entry.level} · {entry.xp} XP</small>
                    </div>
                    {sealClass && <em className={`seal ${sealClass}`}>{pos === 1 ? 'TOP 1' : 'TOP 2'}</em>}
                  </div>
                  <div className="ranking-score">
                    <b>{entry.points_balance}</b>
                    <small>pontos</small>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <div className="ranking-section">
        <div className="ranking-section-head">
          <div className="ranking-icon"><TrendingUp /></div>
          <div>
            <div className="eyebrow purple"><span />TOP INVESTIDORES</div>
            <h3>Top 5 por total investido</h3>
            <p>Recalculado a cada semestre</p>
          </div>
          {period && <span className="ranking-period-badge"><Clock3 /> {fmtDate(period.starts_at)} — {fmtDate(period.ends_at)}</span>}
        </div>
        {investorRank.length === 0 ? <p className="admin-empty-inline">Nenhum investidor classificado neste semestre ainda. O ranking é calculado quando o gerente encerra o período.</p> : (
          <div className="ranking-list">
            {investorRank.map((entry) => {
              const pos = entry.rank_position;
              const rowClass = pos === 1 ? 'top-1' : pos === 2 ? 'top-2' : pos === 3 ? 'top-3' : '';
              let seals: { cls: string; label: string }[] = [];
              if (pos === 5) seals.push({ cls: 'seal-gasta-muito', label: 'GASTA MUITO' });
              if (pos === 2) seals.push({ cls: 'seal-amaldicoado', label: 'AMALDIÇOADO' });
              if (pos === 1) seals.push({ cls: 'seal-top1-global', label: 'TOP 1 INVESTIDOR' });
              return (
                <div className={`ranking-row ${rowClass}`} key={entry.id}>
                  <div className="ranking-position">{pos}</div>
                  <div className="ranking-user">
                    <div className="ranking-user-avatar">{pos === 1 ? <Crown /> : <UserRound />}</div>
                    <div className="ranking-user-info">
                      <strong>{entry.customer_email}</strong>
                      {seals.map((s) => <em key={s.label} className={`seal ${s.cls}`}>{s.label}</em>)}
                    </div>
                  </div>
                  <div className="ranking-score">
                    <b>{fmtBRL(Number(entry.total_spent))}</b>
                    <small>investido</small>
                  </div>
                </div>
              );
            })}
          </div>
        )}
        <small className="admin-note" style={{ marginTop: 12, display: 'block' }}>Os benefícios (selos, banners, molduras e animações) acompanham a posição atual. Itens permanentes permanecem com o cliente mesmo ao perder a posição.</small>
      </div>
    </div>
  );
}

type ShopProduct = { id: string; name: string; description: string; game: string; category: string; price: number; image_url: string | null; is_active: boolean };
type ShopOrder = { id: string; product_name: string; buyer_email: string; nick: string; price: number; status: string; order_number: string; created_at: string };
type ShopData = { id: string; name: string; is_open: boolean; is_suspended: boolean; suspension_reason: string | null };

function CustomerShop({ onNavigate, onNotice }: { onNavigate: (page: Page) => void; onNotice: (message: string) => void }) {
  const [shop, setShop] = useState<ShopData | null>(null);
  const [products, setProducts] = useState<ShopProduct[]>([]);
  const [orders, setOrders] = useState<ShopOrder[]>([]);
  const [canOpen, setCanOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ name: '', description: '', game: '', category: '', price: '' });
  const [shopName, setShopName] = useState('');

  const refresh = async (userId: string, userShopId: string | null) => {
    const queries = [
      supabase.rpc('can_open_shop', { p_user_id: userId }),
    ] as const;
    const [canOpenRes] = await Promise.all(queries);
    setCanOpen((canOpenRes.data as boolean) ?? false);
    if (userShopId) {
      const [prodRes, orderRes] = await Promise.all([
        supabase.from('customer_shop_products').select('id, name, description, game, category, price, image_url, is_active').eq('shop_id', userShopId).order('created_at', { ascending: false }),
        supabase.from('customer_shop_orders').select('id, product_name, buyer_email, nick, price, status, order_number, created_at').eq('shop_id', userShopId).order('created_at', { ascending: false }),
      ]);
      if (prodRes.data) setProducts(prodRes.data as ShopProduct[]);
      if (orderRes.data) setOrders(orderRes.data as ShopOrder[]);
    }
    setLoading(false);
  };

  useEffect(() => {
    void (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { setLoading(false); return; }
      const { data: shopData } = await supabase.from('customer_shops').select('id, name, is_open, is_suspended, suspension_reason').eq('owner_id', user.id).maybeSingle();
      if (shopData) {
        setShop(shopData as ShopData);
        await refresh(user.id, (shopData as ShopData).id);
      } else {
        await refresh(user.id, null);
      }
    })();
  }, []);

  const createShop = async () => {
    if (!shopName.trim()) { onNotice('Defina um nome para sua loja.'); return; }
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const slug = shopName.trim().toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-').slice(0, 40);
    const { data, error } = await supabase.from('customer_shops').insert({ owner_id: user.id, owner_email: user.email ?? '', name: shopName.trim(), slug, is_open: false }).select('id, name, is_open, is_suspended, suspension_reason').maybeSingle();
    if (error) { onNotice('Não foi possível criar a loja. Verifique se você é o Top 1 investidor do semestre.'); return; }
    if (data) { setShop(data as ShopData); onNotice('Loja criada! Adicione produtos e abra quando estiver pronta.'); await refresh(user.id, (data as ShopData).id); }
  };

  const toggleShop = async () => {
    if (!shop || !canOpen) return;
    const { error } = await supabase.from('customer_shops').update({ is_open: !shop.is_open, updated_at: new Date().toISOString() }).eq('id', shop.id);
    if (error) { onNotice('Não foi possível alterar o status da loja.'); return; }
    setShop({ ...shop, is_open: !shop.is_open });
    onNotice(shop.is_open ? 'Loja fechada.' : 'Loja aberta para a comunidade.');
  };

  const addProduct = async () => {
    if (!shop) return;
    const price = Number(form.price.replace(',', '.'));
    if (!form.name.trim() || !Number.isFinite(price) || price < 0) { onNotice('Preencha nome e preço válido.'); return; }
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from('customer_shop_products').insert({ shop_id: shop.id, owner_id: user.id, name: form.name.trim(), description: form.description.trim(), game: form.game.trim(), category: form.category.trim(), price });
    if (error) { onNotice('Não foi possível adicionar o produto.'); return; }
    setForm({ name: '', description: '', game: '', category: '', price: '' });
    setShowForm(false);
    onNotice('Produto adicionado à sua loja.');
    await refresh(user.id, shop.id);
  };

  const toggleProduct = async (product: ShopProduct) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user || !shop) return;
    const { error } = await supabase.from('customer_shop_products').update({ is_active: !product.is_active, updated_at: new Date().toISOString() }).eq('id', product.id);
    if (error) { onNotice('Não foi possível alterar o produto.'); return; }
    onNotice(product.is_active ? 'Produto desativado.' : 'Produto ativado.');
    await refresh(user.id, shop.id);
  };

  const updateOrderStatus = async (order: ShopOrder, status: string) => {
    if (!shop) return;
    const { error } = await supabase.from('customer_shop_orders').update({ status, updated_at: new Date().toISOString() }).eq('id', order.id);
    if (error) { onNotice('Não foi possível atualizar o pedido.'); return; }
    onNotice(`Pedido marcado como ${status}.`);
    const { data: { user } } = await supabase.auth.getUser();
    if (user) await refresh(user.id, shop.id);
  };

  const fmtBRL = (v: number) => `R$ ${v.toFixed(2).replace('.', ',')}`;
  const fmtDate = (v: string) => new Date(v).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });

  if (loading) return <div className="inner-page"><p className="admin-empty-inline">Carregando sua loja...</p></div>;

  if (!canOpen && !shop) {
    return (
      <div className="inner-page">
        <PageHeading eyebrow="LOJA DO INVESTIDOR" title="Minha loja" description="Crie e gerencie sua própria loja na FLIZSTAR." />
        <div className="shop-access-denied">
          <Store />
          <h3>Acesso exclusivo do Top 1 Investidor</h3>
          <p>Apenas o primeiro colocado do Top Investidores no semestre atual pode criar uma loja própria. Continue investindo e participando da comunidade para conquistar essa posição.</p>
          <button className="ghost-button" onClick={() => onNavigate('ranking')}><Trophy /> Ver rankings <ArrowRight /></button>
        </div>
      </div>
    );
  }

  if (!shop) {
    return (
      <div className="inner-page shop-page">
        <PageHeading eyebrow="LOJA DO INVESTIDOR" title="Minha loja" description="Você é o Top 1 Investidor! Crie sua loja agora." />
        <div className="shop-form-card">
          <div className="eyebrow purple"><Store /> CRIAR LOJA</div>
          <h3>Nome da sua loja</h3>
          <label>Nome<input value={shopName} onChange={(e) => setShopName(e.target.value)} placeholder="Ex: Loja do Vantax" maxLength={40} /></label>
          <div className="admin-actions"><button className="primary-button" onClick={createShop}><Plus /> Criar loja</button></div>
        </div>
      </div>
    );
  }

  return (
    <div className="inner-page shop-page">
      <PageHeading eyebrow="LOJA DO INVESTIDOR" title={shop.name} description="Gerencie seus produtos e pedidos." action={<button className="primary-button" onClick={toggleShop} disabled={shop.is_suspended}>{shop.is_open ? 'Fechar loja' : 'Abrir loja'}</button>} />
      {shop.is_suspended && <div className="shop-suspended-banner"><ShieldCheck /> <span>Sua loja foi suspensa pela equipe oficial. Motivo: {shop.suspension_reason || 'não informado'}. Entre em contato com o suporte para esclarecimentos.</span></div>}
      <div className="shop-header">
        <div className="shop-status-badges">
          <em className={`status-badge ${shop.is_open ? 'active' : 'inactive'}`}>{shop.is_open ? 'Aberta' : 'Fechada'}</em>
          {shop.is_suspended && <em className="status-badge banned">Suspensa</em>}
        </div>
        <button className="ghost-button" onClick={() => setShowForm(!showForm)}><Plus /> Adicionar produto</button>
      </div>

      {showForm && (
        <div className="shop-form-card">
          <div className="eyebrow purple">NOVO PRODUTO</div>
          <h3>Adicionar produto</h3>
          <label>Nome<input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Nome do produto" /></label>
          <label>Descrição<textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Descrição do produto" rows={3} /></label>
          <div className="admin-form-row">
            <label>Jogo<input value={form.game} onChange={(e) => setForm({ ...form, game: e.target.value })} placeholder="Roblox, Free Fire..." /></label>
            <label>Categoria<input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Skins, Moedas..." /></label>
          </div>
          <label>Preço (R$)<input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="0,00" inputMode="decimal" /></label>
          <div className="admin-actions"><button className="primary-button" onClick={addProduct}><Save /> Salvar produto</button><button className="ghost-button" onClick={() => setShowForm(false)}>Cancelar</button></div>
        </div>
      )}

      <div>
        <h3 style={{ fontSize: 14, color: '#bc5eff', margin: '20px 0 12px' }}><Package /> Produtos ({products.length})</h3>
        {products.length === 0 ? <p className="admin-empty-inline">Nenhum produto ainda. Adicione o primeiro acima.</p> : (
          <div className="shop-product-grid">
            {products.map((p) => (
              <div className={`shop-product-card ${!p.is_active ? 'suspended' : ''}`} key={p.id}>
                <strong style={{ fontSize: 12, color: '#fff' }}>{p.name}</strong>
                <small style={{ color: 'var(--muted)', fontSize: 10, display: 'block', marginTop: 4 }}>{p.game} · {p.category}</small>
                {p.description && <p style={{ fontSize: 10, color: 'var(--muted)', margin: '6px 0' }}>{p.description}</p>}
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 }}>
                  <b style={{ color: '#fff', fontSize: 12 }}>{fmtBRL(Number(p.price))}</b>
                  <em className={`status-badge ${p.is_active ? 'active' : 'inactive'}`}>{p.is_active ? 'Ativo' : 'Inativo'}</em>
                  <button onClick={() => toggleProduct(p)} style={{ fontSize: 9 }}>{p.is_active ? 'Desativar' : 'Ativar'}</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div>
        <h3 style={{ fontSize: 14, color: '#bc5eff', margin: '20px 0 12px' }}><ShoppingBag /> Pedidos ({orders.length})</h3>
        {orders.length === 0 ? <p className="admin-empty-inline">Nenhum pedido ainda.</p> : (
          <div className="admin-table" style={{ ['--cols' as string]: '5' }}>
            <div className="admin-table-head"><span>Produto</span><span>Cliente</span><span>Valor</span><span>Status</span><span>Ações</span></div>
            {orders.map((o) => (
              <div className="admin-table-row" key={o.id} style={{ ['--cols' as string]: '5' }}>
                <span>{o.product_name}</span>
                <small>{o.buyer_email}</small>
                <b>{fmtBRL(Number(o.price))}</b>
                <em className={`status-badge ${o.status}`}>{o.status}</em>
                <div className="admin-row-actions">
                  {o.status === 'pending' && <button onClick={() => updateOrderStatus(o, 'paid')}>Marcar pago</button>}
                  {o.status === 'paid' && <button onClick={() => updateOrderStatus(o, 'delivered')}>Entregar</button>}
                  {o.status !== 'cancelled' && <button className="danger" onClick={() => updateOrderStatus(o, 'cancelled')}>Cancelar</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <small className="admin-note">A equipe oficial pode fiscalizar sua loja, retirar produtos e solicitar esclarecimentos. Situações de pedidos em andamento ainda não definidas serão sinalizadas para decisão da administração.</small>
    </div>
  );
}

function EmptyState({ text }: { text: string }) { return <div className="empty-state"><Package /><strong>{text}</strong><span>Tente ajustar os filtros e buscar novamente.</span></div>; }

export default App;
