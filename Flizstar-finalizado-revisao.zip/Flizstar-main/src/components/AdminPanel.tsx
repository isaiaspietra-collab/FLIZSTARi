import { useCallback, useEffect, useState, type ReactNode } from 'react';
import { supabase } from '@/lib/supabase';
import {
  ArrowRight,
  BadgeCheck,
  BarChart3,
  Gift,
  LogOut,
  Package,
  Plus,
  Save,
  Pencil,
  Trash2,
  ShoppingBag,
  Sparkles,
  Star,
  Ticket,
  TrendingUp,
  Users,
  HeartHandshake,
  ShieldCheck,
  Clock3,
  Tag,
  Coins,
  CalendarDays,
  Eye,
  Crown,
  Search,
  Store,
  Trophy,
  Ban,
  Undo2,
  FileText,
  History,
  Zap,
  X,
  UserRound,
  RefreshCw,
  AlertTriangle,
} from 'lucide-react';

type Product = {
  id: string | number;
  name: string;
  game: string;
  category: string;
  description: string;
  price: number;
  color: string;
  icon: string;
  availability: string;
  delivery: string;
  image_url?: string;
  pending_price?: number | null;
  pending_price_eligible_at?: string | null;
  is_active?: boolean;
};

type DbProduct = {
  id: string;
  name: string;
  description: string;
  game: string;
  category: string;
  image_url: string | null;
  price: number;
  is_active: boolean;
  is_demo: boolean;
  pending_price: number | null;
  pending_price_eligible_at: string | null;
  created_at: string;
  updated_at: string;
};

type Order = {
  id: string;
  product_name: string;
  customer_email: string;
  nick: string;
  price: number;
  status: string;
  payment_method: string;
  order_number: string;
  is_demo: boolean;
  created_at: string;
};

type TradeOffer = {
  id: string;
  game: string;
  offer: string;
  looking: string;
  user_email: string;
  status: string;
  created_at: string;
};

type GoldenTicket = {
  id: string;
  code: string;
  customer_email: string;
  status: string;
  prize: string;
  expires_at: string | null;
  created_at: string;
};

type EventItem = {
  id: string;
  name: string;
  description: string;
  type: string;
  is_active: boolean;
  starts_at: string | null;
  ends_at: string | null;
};

type Discount = {
  id: string;
  code: string;
  percent: number;
  is_active: boolean;
  expires_at: string | null;
  product_id: string | null;
};

type CustomerPoints = {
  id: string;
  customer_email: string;
  balance: number;
  created_at: string;
};

type CustomerProfile = {
  id: string;
  email: string;
  role: string;
  created_at: string;
  nick?: string | null;
  bio?: string | null;
  level?: number;
  xp?: number;
  is_banned?: boolean;
  updated_at?: string;
};

type InventoryItem = {
  id: string;
  customer_id: string;
  customer_email: string;
  product_id: string | null;
  product_name: string;
  source: string;
  granted_at: string;
};

type AdminActionEntry = {
  id: string;
  manager_email: string;
  target_customer_email: string;
  action: string;
  reason: string;
  details?: string | null;
  created_at: string;
};

type GiftCard = {
  id: string;
  code: string;
  value: number;
  customer_email: string;
  status: string;
  expires_at: string | null;
  created_at: string;
};

type PriceChange = {
  id: string;
  product_name: string;
  old_price: number;
  new_price: number;
  status: string;
  eligible_at: string;
  created_at: string;
};

type TabId =
  | 'overview'
  | 'products'
  | 'orders'
  | 'customers'
  | 'trades'
  | 'golden-ticket'
  | 'events'
  | 'discounts'
  | 'points'
  | 'gift-cards'
  | 'shops';

const tabs: { id: TabId; label: string; icon: typeof Package }[] = [
  { id: 'overview', label: 'Visão geral', icon: BarChart3 },
  { id: 'products', label: 'Produtos e preços', icon: Package },
  { id: 'orders', label: 'Pedidos e vendas', icon: ShoppingBag },
  { id: 'customers', label: 'Clientes', icon: Users },
  { id: 'trades', label: 'Trocas', icon: HeartHandshake },
  { id: 'golden-ticket', label: 'Ticket Dourado', icon: Ticket },
  { id: 'events', label: 'Eventos', icon: CalendarDays },
  { id: 'discounts', label: 'Descontos', icon: Tag },
  { id: 'points', label: 'Pontos', icon: Coins },
  { id: 'gift-cards', label: 'Gift Cards', icon: Gift },
  { id: 'shops', label: 'Loja ADM / lojas', icon: Store },
];

function productVisual(game: string, category: string) {
  const visualByGame: Record<string, { color: string; icon: string }> = {
    Roblox: { color: 'cyan', icon: '✦' },
    'Free Fire': { color: 'pink', icon: '◆' },
    'Brawl Stars': { color: 'orange', icon: '✹' },
    PUBG: { color: 'gold', icon: '⬡' },
  };
  return visualByGame[game] ?? { color: 'violet', icon: category.slice(0, 1).toUpperCase() };
}

function fromDatabaseProduct(row: DbProduct): Product {
  const visual = productVisual(row.game, row.category);
  return {
    id: row.id,
    name: row.name,
    description: row.description,
    game: row.game,
    category: row.category,
    image_url: row.image_url ?? undefined,
    price: Number(row.price),
    color: visual.color,
    icon: visual.icon,
    availability: row.is_active ? 'Ativo no catálogo' : 'Inativo no catálogo',
    delivery: 'Definida pelo gerente após a configuração da operação',
    pending_price: row.pending_price != null ? Number(row.pending_price) : null,
    pending_price_eligible_at: row.pending_price_eligible_at,
    is_active: row.is_active,
  };
}

const fmtBRL = (value: number) => `R$ ${value.toFixed(2).replace('.', ',')}`;
const fmtDate = (value: string | null) => (value ? new Date(value).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' }) : '—');

export function AdminPanel({ onNotice }: { onNotice: (message: string) => void }) {
  const [tab, setTab] = useState<TabId>('overview');
  const [catalog, setCatalog] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [trades, setTrades] = useState<TradeOffer[]>([]);
  const [tickets, setTickets] = useState<GoldenTicket[]>([]);
  const [events, setEvents] = useState<EventItem[]>([]);
  const [discounts, setDiscounts] = useState<Discount[]>([]);
  const [points, setPoints] = useState<CustomerPoints[]>([]);
  const [giftCards, setGiftCards] = useState<GiftCard[]>([]);
  const [priceChanges, setPriceChanges] = useState<PriceChange[]>([]);
  const [customers, setCustomers] = useState<CustomerProfile[]>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [actionLog, setActionLog] = useState<AdminActionEntry[]>([]);
  const [shops, setShops] = useState<AdminShop[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  const refreshAll = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      const results = await Promise.all([
        supabase.from('products').select('*').order('created_at', { ascending: false }),
        supabase.from('orders').select('*').order('created_at', { ascending: false }).limit(100),
        supabase.from('trade_offers').select('*').order('created_at', { ascending: false }).limit(100),
        supabase.from('golden_tickets').select('*').order('created_at', { ascending: false }),
        supabase.from('events').select('*').order('created_at', { ascending: false }),
        supabase.from('discounts').select('*').order('created_at', { ascending: false }),
        supabase.from('customer_points').select('*').order('created_at', { ascending: false }),
        supabase.from('gift_cards').select('*').order('created_at', { ascending: false }),
        supabase.from('price_change_log').select('*').order('created_at', { ascending: false }).limit(50),
        supabase.from('profiles').select('*').order('created_at', { ascending: false }),
        supabase.from('customer_inventory').select('*').order('granted_at', { ascending: false }),
        supabase.from('admin_action_log').select('*').order('created_at', { ascending: false }).limit(200),
        supabase.from('customer_shops').select('id, owner_id, owner_email, name, slug, is_open, is_suspended, suspension_reason, created_at').order('created_at', { ascending: false }),
      ]);
      const [productsRes, ordersRes, tradesRes, ticketsRes, eventsRes, discountsRes, pointsRes, giftRes, priceLogRes, profilesRes, inventoryRes, actionLogRes, shopsRes] = results;
      if (productsRes.data) setCatalog((productsRes.data as DbProduct[]).map(fromDatabaseProduct));
      if (ordersRes.data) setOrders(ordersRes.data as Order[]);
      if (tradesRes.data) setTrades(tradesRes.data as TradeOffer[]);
      if (ticketsRes.data) setTickets(ticketsRes.data as GoldenTicket[]);
      if (eventsRes.data) setEvents(eventsRes.data as EventItem[]);
      if (discountsRes.data) setDiscounts(discountsRes.data as Discount[]);
      if (pointsRes.data) setPoints(pointsRes.data as CustomerPoints[]);
      if (giftRes.data) setGiftCards(giftRes.data as GiftCard[]);
      if (priceLogRes.data) setPriceChanges(priceLogRes.data as PriceChange[]);
      if (profilesRes.data) setCustomers(profilesRes.data as CustomerProfile[]);
      if (inventoryRes.data) setInventory(inventoryRes.data as InventoryItem[]);
      if (actionLogRes.data) setActionLog(actionLogRes.data as AdminActionEntry[]);
      if (shopsRes.data) setShops(shopsRes.data as AdminShop[]);
      const failed = results.filter((result) => result.error);
      if (failed.length) {
        setLoadError(`Algumas consultas não carregaram (${failed.length} de ${results.length}). Verifique se as migrações do Supabase foram aplicadas e se a conta tem permissão de gerente.`);
      }
    } catch {
      setLoadError('Não foi possível carregar os dados administrativos. Confira a conexão e as configurações do Supabase.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refreshAll();
  }, [refreshAll]);

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    onNotice('Você saiu da conta de gerente.');
  };

  return (
    <div className="admin-page">
      <div className="admin-header">
        <div>
          <div className="eyebrow purple">FLIZSTAR CONTROL</div>
          <h2>Painel administrativo</h2>
          <p>Gerencie o catálogo, pedidos, clientes, trocas, eventos e muito mais.</p>
        </div>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', alignItems: 'center' }}>
          <button className="ghost-button" onClick={() => void refreshAll()} disabled={loading}>
            <RefreshCw className={loading ? 'animate-spin' : ''} /> {loading ? 'Atualizando...' : 'Atualizar dados'}
          </button>
          <button className="ghost-button" onClick={handleSignOut}>
            <LogOut /> Sair
          </button>
        </div>
      </div>

      <div className="admin-tabs">
        {tabs.map((t) => {
          const Icon = t.icon;
          return (
            <button key={t.id} className={`admin-tab ${tab === t.id ? 'active' : ''}`} onClick={() => setTab(t.id)}>
              <Icon />
              <span>{t.label}</span>
            </button>
          );
        })}
      </div>

      {loadError && <div role="alert" className="admin-security-note" style={{ borderColor: 'rgba(245, 158, 11, .45)', color: '#fcdba5', marginBottom: 16 }}><AlertTriangle /><span><strong>Verificação necessária</strong> {loadError}</span></div>}
      <div className="admin-tab-content">
        {loading && <div className="admin-loading">Carregando dados...</div>}
        {!loading && tab === 'overview' && <OverviewTab catalog={catalog} orders={orders} trades={trades} customers={customers} events={events} tickets={tickets} giftCards={giftCards} points={points} />}
        {!loading && tab === 'products' && <ProductsTab catalog={catalog} priceChanges={priceChanges} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'orders' && <OrdersTab orders={orders} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'customers' && <CustomersTab customers={customers} points={points} orders={orders} trades={trades} tickets={tickets} giftCards={giftCards} inventory={inventory} actionLog={actionLog} catalog={catalog} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'trades' && <TradesTab trades={trades} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'golden-ticket' && <GoldenTicketTab tickets={tickets} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'events' && <EventsTab events={events} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'discounts' && <DiscountsTab discounts={discounts} catalog={catalog} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'points' && <PointsTab points={points} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'gift-cards' && <GiftCardsTab giftCards={giftCards} onChanged={refreshAll} onNotice={onNotice} />}
        {!loading && tab === 'shops' && <ShopsTab shops={shops} onChanged={refreshAll} onNotice={onNotice} />}
      </div>

      <div className="admin-security-note">
        <ShieldCheck />
        <span>
          <strong>Contas separadas</strong> Clientes continuam sem acesso administrativo. Gerentes são definidos no banco de dados.
        </span>
      </div>
    </div>
  );
}

function StatCard({ icon, label, value, accent }: { icon: ReactNode; label: string; value: string | number; accent?: string }) {
  return (
    <div className={`admin-stat-card ${accent ?? ''}`}>
      <div className="admin-stat-icon">{icon}</div>
      <div>
        <small>{label}</small>
        <strong>{value}</strong>
      </div>
    </div>
  );
}

function OverviewTab({ catalog, orders, trades, customers, events, tickets, giftCards, points }: { catalog: Product[]; orders: Order[]; trades: TradeOffer[]; customers: { id: string; email: string; role: string }[]; events: EventItem[]; tickets: GoldenTicket[]; giftCards: GiftCard[]; points: CustomerPoints[] }) {
  const totalRevenue = orders.filter((o) => o.status === 'paid' || o.status === 'delivered').reduce((sum, o) => sum + Number(o.price), 0);
  const activeEvents = events.filter((e) => e.is_active).length;
  const openTrades = trades.filter((t) => t.status === 'open').length;
  const redeemedTickets = tickets.filter((t) => t.status === 'redeemed').length;
  const totalPointsIssued = points.reduce((sum, p) => sum + p.balance, 0);
  const activeGiftCards = giftCards.filter((g) => g.status === 'unused').length;

  return (
    <div className="admin-overview">
      <div className="admin-stats-grid">
        <StatCard icon={<Package />} label="Produtos no catálogo" value={catalog.length} />
        <StatCard icon={<ShoppingBag />} label="Pedidos totais" value={orders.length} accent="purple" />
        <StatCard icon={<TrendingUp />} label="Receita (pago/entregue)" value={fmtBRL(totalRevenue)} accent="green" />
        <StatCard icon={<Users />} label="Clientes cadastrados" value={customers.length} />
        <StatCard icon={<HeartHandshake />} label="Trocas abertas" value={openTrades} accent="pink" />
        <StatCard icon={<CalendarDays />} label="Eventos ativos" value={activeEvents} accent="cyan" />
        <StatCard icon={<Ticket />} label="Tickets resgatados" value={redeemedTickets} accent="gold" />
        <StatCard icon={<Coins />} label="Pontos emitidos" value={totalPointsIssued} accent="orange" />
        <StatCard icon={<Gift />} label="Gift cards ativos" value={activeGiftCards} accent="violet" />
      </div>

      <div className="admin-overview-section">
        <h3><Eye /> Resumo recente</h3>
        <div className="admin-overview-grid">
          <div className="admin-mini-panel">
            <h4>Pedidos recentes</h4>
            {orders.slice(0, 5).map((o) => (
              <div className="admin-mini-row" key={o.id}>
                <span>{o.product_name || '—'}</span>
                <small>{o.customer_email}</small>
                <b>{fmtBRL(Number(o.price))}</b>
                <em className={`status-badge ${o.status}`}>{o.status}</em>
              </div>
            ))}
            {orders.length === 0 && <p className="admin-empty-inline">Nenhum pedido ainda.</p>}
          </div>
          <div className="admin-mini-panel">
            <h4>Trocas recentes</h4>
            {trades.slice(0, 5).map((t) => (
              <div className="admin-mini-row" key={t.id}>
                <span>{t.offer}</span>
                <small>{t.user_email}</small>
                <em className={`status-badge ${t.status}`}>{t.status}</em>
              </div>
            ))}
            {trades.length === 0 && <p className="admin-empty-inline">Nenhuma troca ainda.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}

function ProductsTab({ catalog, priceChanges, onChanged, onNotice }: { catalog: Product[]; priceChanges: PriceChange[]; onChanged: () => Promise<void>; onNotice: (message: string) => void }) {
  const emptyForm = { name: '', description: '', game: 'Roblox', category: 'Itens', image_url: '', price: '' };
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState<string | number | null>(null);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const startEdit = (product: Product) => {
    setEditingId(product.id);
    setForm({ name: product.name, description: product.description, game: product.game, category: product.category, image_url: product.image_url ?? '', price: product.price.toFixed(2) });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const reset = () => {
    setEditingId(null);
    setForm(emptyForm);
    setError('');
  };

  const save = async () => {
    const price = Number(form.price.replace(',', '.'));
    if (!form.name.trim() || !form.description.trim() || !form.game.trim() || !form.category.trim() || !Number.isFinite(price) || price < 0) {
      setError('Preencha nome, descrição, jogo, categoria e um preço válido.');
      return;
    }
    setSaving(true);
    setError('');
    const payload = {
      name: form.name.trim(),
      description: form.description.trim(),
      game: form.game.trim(),
      category: form.category.trim(),
      image_url: form.image_url.trim() || null,
      price,
      is_active: true,
      is_demo: true,
      updated_at: new Date().toISOString(),
    };
    const result = editingId
      ? await supabase.from('products').update(payload).eq('id', editingId)
      : await supabase.from('products').insert(payload);
    setSaving(false);
    if (result.error) {
      setError('Não foi possível salvar o produto. Verifique o acesso de gerente.');
      return;
    }
    await onChanged();
    onNotice(editingId ? 'Produto atualizado na Loja.' : 'Produto cadastrado na Loja.');
    reset();
  };

  const remove = async (product: Product) => {
    if (!window.confirm(`Excluir o produto ${product.name}?`)) return;
    const { error: deleteError } = await supabase.from('products').delete().eq('id', product.id);
    if (deleteError) {
      setError('Não foi possível excluir o produto.');
      return;
    }
    await onChanged();
    onNotice('Produto excluído da Loja.');
  };

  const toggleActive = async (product: Product) => {
    const { error: toggleError } = await supabase.from('products').update({ is_active: !product.is_active, updated_at: new Date().toISOString() }).eq('id', product.id);
    if (toggleError) {
      onNotice('Não foi possível alterar o status do produto.');
      return;
    }
    await onChanged();
    onNotice(product.is_active ? 'Produto desativado.' : 'Produto ativado.');
  };

  const requestPriceChange = async (product: Product) => {
    const input = window.prompt(`Novo preço para ${product.name} (atual: ${fmtBRL(product.price)}):`, product.price.toFixed(2));
    if (!input) return;
    const newPrice = Number(input.replace(',', '.'));
    if (!Number.isFinite(newPrice) || newPrice < 0) {
      onNotice('Preço inválido.');
      return;
    }
    const eligibleAt = new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString();
    const { error: logError } = await supabase.from('price_change_log').insert({
      product_id: product.id,
      product_name: product.name,
      old_price: product.price,
      new_price: newPrice,
      status: 'pending',
      eligible_at: eligibleAt,
    });
    if (logError) {
      onNotice('Não foi possível registrar a alteração de preço.');
      return;
    }
    const { error: updateError } = await supabase
      .from('products')
      .update({ pending_price: newPrice, pending_price_eligible_at: eligibleAt, updated_at: new Date().toISOString() })
      .eq('id', product.id);
    if (updateError) {
      onNotice('Preço pendente registrado, mas houve erro ao vincular ao produto.');
    } else {
      onNotice(`Alteração de preço registrada. Poderá ser aplicada após 12 horas (${new Date(eligibleAt).toLocaleString('pt-BR')}).`);
    }
    await onChanged();
  };

  const applyPendingPrice = async (product: Product) => {
    if (!product.pending_price || !product.pending_price_eligible_at) return;
    const eligible = new Date(product.pending_price_eligible_at).getTime();
    if (Date.now() < eligible) {
      const remaining = Math.ceil((eligible - Date.now()) / (60 * 60 * 1000));
      onNotice(`Ainda faltam ${remaining}h para o preço poder ser aplicado.`);
      return;
    }
    const { error: applyError } = await supabase
      .from('products')
      .update({ price: product.pending_price, pending_price: null, pending_price_eligible_at: null, updated_at: new Date().toISOString() })
      .eq('id', product.id);
    if (applyError) {
      onNotice('Não foi possível aplicar o preço pendente.');
      return;
    }
    await supabase.from('price_change_log').update({ status: 'applied', updated_at: new Date().toISOString() }).eq('product_name', product.name).eq('status', 'pending');
    await onChanged();
    onNotice('Preço aplicado com sucesso.');
  };

  return (
    <div className="admin-grid">
      <section className="admin-form-card">
        <div className="eyebrow purple">{editingId ? 'EDITAR PRODUTO' : 'NOVO PRODUTO'}</div>
        <h3>{editingId ? 'Atualizar item' : 'Cadastrar item'}</h3>
        <label>Nome
          <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Nome do produto" />
        </label>
        <label>Descrição
          <textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Descrição apresentada na Loja" rows={4} />
        </label>
        <div className="admin-form-row">
          <label>Jogo
            <input value={form.game} onChange={(e) => setForm({ ...form, game: e.target.value })} />
          </label>
          <label>Categoria
            <input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} />
          </label>
        </div>
        <label>Imagem
          <input value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} placeholder="URL da imagem (opcional)" />
        </label>
        <label>Preço em reais
          <input value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} placeholder="0,00" inputMode="decimal" />
        </label>
        {error && <div className="auth-error">{error}</div>}
        <div className="admin-actions">
          <button className="primary-button" disabled={saving} onClick={save}>
            {editingId ? <Save /> : <Plus />}{saving ? 'Salvando...' : editingId ? 'Salvar alterações' : 'Cadastrar produto'}
          </button>
          {editingId && <button className="ghost-button" onClick={reset}>Cancelar</button>}
        </div>
      </section>

      <section className="admin-list-card">
        <div className="admin-list-heading">
          <div>
            <div className="eyebrow purple">CATÁLOGO ATUAL</div>
            <h3>{catalog.length} produtos na Loja</h3>
          </div>
          <Package />
        </div>
        {catalog.length === 0 ? (
          <div className="empty-state"><Package /><strong>Nenhum produto cadastrado.</strong><span>Comece cadastrando acima.</span></div>
        ) : (
          <div className="admin-product-list">
            {catalog.map((product) => (
              <div className="admin-product-row" key={product.id}>
                <div className={`mini-product ${product.color}`}>{product.image_url ? <img src={product.image_url} alt="" /> : product.icon}</div>
                <div>
                  <strong>{product.name}</strong>
                  <small>{product.game} · {product.category} · {product.is_active ? 'Ativo' : 'Inativo'}</small>
                  {product.pending_price != null && (
                    <small className="pending-price-tag">
                      <Clock3 /> Pendente: {fmtBRL(product.pending_price)}
                    </small>
                  )}
                </div>
                <b>{fmtBRL(product.price)}</b>
                <button onClick={() => startEdit(product)} aria-label={`Editar ${product.name}`}><Pencil /></button>
                <button onClick={() => remove(product)} aria-label={`Excluir ${product.name}`}><Trash2 /></button>
                <button onClick={() => toggleActive(product)} aria-label={`Ativar/desativar ${product.name}`} className="toggle-btn"><Eye /></button>
                <button onClick={() => requestPriceChange(product)} aria-label={`Alterar preço ${product.name}`}><Tag /></button>
                {product.pending_price != null && (
                  <button onClick={() => applyPendingPrice(product)} aria-label={`Aplicar preço pendente ${product.name}`} className="apply-btn"><BadgeCheck /></button>
                )}
              </div>
            ))}
          </div>
        )}

        {priceChanges.length > 0 && (
          <div className="price-change-section">
            <h4><Clock3 /> Alterações de preço (espera de 12h)</h4>
            <div className="price-change-list">
              {priceChanges.map((pc) => {
                const eligible = new Date(pc.eligible_at).getTime();
                const canApply = Date.now() >= eligible && pc.status === 'pending';
                return (
                  <div className="price-change-row" key={pc.id}>
                    <span>{pc.product_name}</span>
                    <small>{fmtBRL(pc.old_price)} → {fmtBRL(pc.new_price)}</small>
                    <em className={`status-badge ${pc.status}`}>{canApply ? 'pronto para aplicar' : pc.status}</em>
                    <small>{fmtDate(pc.eligible_at)}</small>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}

function OrdersTab({ orders, onChanged, onNotice }: { orders: Order[]; onChanged: () => Promise<void>; onNotice: (message: string) => void }) {
  const updateStatus = async (order: Order, status: string) => {
    const { error: updateError } = await supabase.from('orders').update({ status, updated_at: new Date().toISOString() }).eq('id', order.id);
    if (updateError) {
      onNotice('Não foi possível atualizar o pedido.');
      return;
    }
    await onChanged();
    onNotice(`Pedido ${order.order_number || order.id.slice(0, 8)} marcado como ${status}.`);
  };

  return (
    <div className="admin-list-section">
      <div className="admin-list-heading">
        <div>
          <div className="eyebrow purple">PEDIDOS E VENDAS</div>
          <h3>{orders.length} pedidos</h3>
        </div>
        <ShoppingBag />
      </div>
      {orders.length === 0 ? (
        <div className="empty-state"><ShoppingBag /><strong>Nenhum pedido registrado.</strong><span>Os pedidos aparecerão aqui assim que forem criados.</span></div>
      ) : (
        <div className="admin-table">
          <div className="admin-table-head">
            <span>Pedido</span>
            <span>Produto</span>
            <span>Cliente</span>
            <span>Valor</span>
            <span>Status</span>
            <span>Ações</span>
          </div>
          {orders.map((order) => (
            <div className="admin-table-row" key={order.id}>
              <span className="mono">{order.order_number || order.id.slice(0, 8)}</span>
              <span>{order.product_name || '—'}</span>
              <small>{order.customer_email}</small>
              <b>{fmtBRL(Number(order.price))}</b>
              <em className={`status-badge ${order.status}`}>{order.status}</em>
              <div className="admin-row-actions">
                {order.status === 'pending' && <button onClick={() => updateStatus(order, 'paid')}>Marcar pago</button>}
                {order.status === 'paid' && <button onClick={() => updateStatus(order, 'delivered')}>Entregar</button>}
                {order.status !== 'cancelled' && <button className="danger" onClick={() => updateStatus(order, 'cancelled')}>Cancelar</button>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function CustomersTab({ customers, points, orders, trades, tickets, giftCards, inventory, actionLog, catalog, onChanged, onNotice }: {
  customers: CustomerProfile[];
  points: CustomerPoints[];
  orders: Order[];
  trades: TradeOffer[];
  tickets: GoldenTicket[];
  giftCards: GiftCard[];
  inventory: InventoryItem[];
  actionLog: AdminActionEntry[];
  catalog: Product[];
  onChanged: () => Promise<void>;
  onNotice: (message: string) => void;
}) {
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [actionReason, setActionReason] = useState('');
  const [actionMode, setActionMode] = useState<string | null>(null);
  const [actionValue, setActionValue] = useState('');
  const [grantProductId, setGrantProductId] = useState('');

  const filtered = customers.filter((c) =>
    `${c.email} ${c.nick ?? ''} ${c.role}`.toLowerCase().includes(search.toLowerCase())
  );
  const selected = customers.find((c) => c.id === selectedId) ?? null;

  const customerOrders = orders.filter((o) => o.customer_email === selected?.email);
  const customerTrades = trades.filter((t) => t.user_email === selected?.email);
  const customerTickets = tickets.filter((t) => t.customer_email === selected?.email);
  const customerGifts = giftCards.filter((g) => g.customer_email === selected?.email);
  const customerInventory = inventory.filter((i) => i.customer_id === selected?.id);
  const customerLog = actionLog.filter((a) => a.target_customer_id === selected?.id);
  const customerPoints = points.find((p) => p.customer_email === selected?.email);

  const logAction = async (action: string, reason: string, details?: string) => {
    if (!selected) return;
    const { data: sessionData } = await supabase.auth.getUser();
    const managerEmail = sessionData.user?.email ?? 'gerente';
    await supabase.from('admin_action_log').insert({
      manager_id: sessionData.user?.id ?? null,
      manager_email: managerEmail,
      target_customer_id: selected.id,
      target_customer_email: selected.email,
      action,
      reason,
      details: details ?? null,
    });
  };

  const executeAction = async () => {
    if (!selected || !actionMode) return;
    if (!actionReason.trim()) {
      onNotice('A justificativa é obrigatória para toda ação administrativa.');
      return;
    }
    const reason = actionReason.trim();

    if (actionMode === 'ban') {
      const { error } = await supabase.from('profiles').update({ is_banned: true, updated_at: new Date().toISOString() }).eq('id', selected.id);
      if (error) { onNotice('Erro ao banir cliente.'); return; }
      await logAction('ban', reason);
      onNotice(`Cliente ${selected.email} banido.`);
    } else if (actionMode === 'unban') {
      const { error } = await supabase.from('profiles').update({ is_banned: false, updated_at: new Date().toISOString() }).eq('id', selected.id);
      if (error) { onNotice('Erro ao desbanir cliente.'); return; }
      await logAction('unban', reason);
      onNotice(`Cliente ${selected.email} desbanido.`);
    } else if (actionMode === 'set_level') {
      const level = Math.max(1, Math.floor(Number(actionValue)) || 1);
      const { error } = await supabase.from('profiles').update({ level, updated_at: new Date().toISOString() }).eq('id', selected.id);
      if (error) { onNotice('Erro ao definir nível.'); return; }
      await logAction('set_level', reason, `nível ${level}`);
      onNotice(`Nível de ${selected.email} definido para ${level}.`);
    } else if (actionMode === 'set_xp') {
      const xp = Math.max(0, Math.floor(Number(actionValue)) || 0);
      const { error } = await supabase.from('profiles').update({ xp, updated_at: new Date().toISOString() }).eq('id', selected.id);
      if (error) { onNotice('Erro ao definir XP.'); return; }
      await logAction('set_xp', reason, `${xp} XP`);
      onNotice(`XP de ${selected.email} definido para ${xp}.`);
    } else if (actionMode === 'adjust_points') {
      const delta = Number(actionValue);
      if (!Number.isFinite(delta) || delta === 0) { onNotice('Informe um valor válido de pontos.'); return; }
      if (customerPoints) {
        const newBalance = Math.max(0, customerPoints.balance + delta);
        const { error } = await supabase.from('customer_points').update({ balance: newBalance, updated_at: new Date().toISOString() }).eq('id', customerPoints.id);
        if (error) { onNotice('Erro ao ajustar pontos.'); return; }
      } else {
        const { error } = await supabase.from('customer_points').insert({ customer_id: selected.id, customer_email: selected.email, balance: Math.max(0, delta) });
        if (error) { onNotice('Erro ao criar registro de pontos.'); return; }
      }
      await logAction('adjust_points', reason, `${delta > 0 ? '+' : ''}${delta} pontos`);
      onNotice(`${delta > 0 ? '+' : ''}${delta} pontos ajustados para ${selected.email}.`);
    } else if (actionMode === 'grant_item') {
      const product = catalog.find((p) => p.id === grantProductId);
      if (!product) { onNotice('Selecione um produto para conceder.'); return; }
      const { error } = await supabase.from('customer_inventory').insert({
        customer_id: selected.id,
        customer_email: selected.email,
        product_id: String(product.id),
        product_name: product.name,
        source: 'admin',
      });
      if (error) { onNotice('Erro ao conceder item.'); return; }
      await logAction('grant_item', reason, product.name);
      onNotice(`Item "${product.name}" concedido a ${selected.email}.`);
    } else if (actionMode === 'note') {
      await logAction('note', reason, actionValue.trim() || undefined);
      onNotice(`Anotação registrada para ${selected.email}.`);
    }

    setActionMode(null);
    setActionReason('');
    setActionValue('');
    setGrantProductId('');
    await onChanged();
  };

  const revokeInventoryItem = async (item: InventoryItem) => {
    if (!selected) return;
    const reason = window.prompt(`Justificativa para revogar o item "${item.product_name}" do cliente ${selected.email}:`);
    if (!reason?.trim()) return;
    const { error } = await supabase.from('customer_inventory').delete().eq('id', item.id);
    if (error) { onNotice('Erro ao revogar item.'); return; }
    await logAction('revoke_item', reason.trim(), item.product_name);
    await onChanged();
    onNotice(`Item "${item.product_name}" revogado de ${selected.email}.`);
  };

  if (selected) {
    const level = selected.level ?? 1;
    const xp = selected.xp ?? 0;
    const xpForNext = level * 1000;
    const xpProgress = Math.min(100, (xp / xpForNext) * 100);
    return (
      <div className="customer-detail">
        <button className="ghost-button" onClick={() => setSelectedId(null)}><ArrowRight /> Voltar para lista</button>
        <div className="customer-profile-card">
          <div className="customer-profile-header">
            <div className="customer-avatar"><UserRound /></div>
            <div className="customer-profile-info">
              <div className="customer-name-row">
                <h3>{selected.nick || selected.email}</h3>
                {selected.is_banned && <em className="status-badge banned">Banido</em>}
                <em className={`role-badge ${selected.role}`}>{selected.role === 'manager' ? 'Gerente' : 'Cliente'}</em>
              </div>
              <small>{selected.email}</small>
              <small>Cadastro: {fmtDate(selected.created_at)}</small>
              {selected.bio && <p className="customer-bio">{selected.bio}</p>}
            </div>
          </div>
          <div className="customer-level-bar">
            <div className="customer-level-stats">
              <span><Zap /> Nível {level}</span>
              <small>{xp} / {xpForNext} XP</small>
            </div>
            <div className="xp-bar-track"><div className="xp-bar-fill" style={{ width: `${xpProgress}%` }} /></div>
          </div>
          <div className="customer-quick-stats">
            <div><Coins /> <b>{customerPoints?.balance ?? 0}</b><small>pontos</small></div>
            <div><ShoppingBag /> <b>{customerOrders.length}</b><small>compras</small></div>
            <div><Package /> <b>{customerInventory.length}</b><small>inventário</small></div>
            <div><HeartHandshake /> <b>{customerTrades.length}</b><small>trocas</small></div>
            <div><Gift /> <b>{customerGifts.length}</b><small>gift cards</small></div>
            <div><Ticket /> <b>{customerTickets.length}</b><small>tickets</small></div>
          </div>
        </div>

        <div className="customer-actions-panel">
          <h4><ShieldCheck /> Ações administrativas</h4>
          <div className="customer-action-buttons">
            <button className={selected.is_banned ? '' : 'danger'} onClick={() => { setActionMode(selected.is_banned ? 'unban' : 'ban'); setActionReason(''); setActionValue(''); }}>
              {selected.is_banned ? <><Undo2 /> Desbanir</> : <><Ban /> Banir</>}
            </button>
            <button onClick={() => { setActionMode('set_level'); setActionReason(''); setActionValue(String(level)); }}><Crown /> Definir nível</button>
            <button onClick={() => { setActionMode('set_xp'); setActionReason(''); setActionValue(String(xp)); }}><Zap /> Definir XP</button>
            <button onClick={() => { setActionMode('adjust_points'); setActionReason(''); setActionValue(''); }}><Coins /> Ajustar pontos</button>
            <button onClick={() => { setActionMode('grant_item'); setActionReason(''); setActionValue(''); setGrantProductId(catalog[0]?.id ? String(catalog[0].id) : ''); }}><Gift /> Conceder item</button>
            <button onClick={() => { setActionMode('note'); setActionReason(''); setActionValue(''); }}><FileText /> Registrar anotação</button>
          </div>
          {actionMode && (
            <div className="customer-action-form">
              <div className="eyebrow purple">{actionMode === 'ban' ? 'BANIR CLIENTE' : actionMode === 'unban' ? 'DESBANIR CLIENTE' : actionMode === 'set_level' ? 'DEFINIR NÍVEL' : actionMode === 'set_xp' ? 'DEFINIR XP' : actionMode === 'adjust_points' ? 'AJUSTAR PONTOS' : actionMode === 'grant_item' ? 'CONCEDER ITEM' : 'REGISTRAR ANOTAÇÃO'}</div>
              {(actionMode === 'set_level' || actionMode === 'set_xp' || actionMode === 'adjust_points') && (
                <label>{actionMode === 'adjust_points' ? 'Pontos (+/-)' : 'Valor'}
                  <input value={actionValue} onChange={(e) => setActionValue(e.target.value)} type={actionMode === 'adjust_points' ? 'number' : 'number'} placeholder={actionMode === 'adjust_points' ? '100 ou -50' : '0'} />
                </label>
              )}
              {actionMode === 'grant_item' && (
                <label>Produto
                  <select value={grantProductId} onChange={(e) => setGrantProductId(e.target.value)}>
                    {catalog.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                </label>
              )}
              {actionMode === 'note' && (
                <label>Detalhe (opcional)
                  <input value={actionValue} onChange={(e) => setActionValue(e.target.value)} placeholder="Descrição da anotação" />
                </label>
              )}
              <label>Justificativa <span className="required-marker">obrigatória</span>
                <textarea value={actionReason} onChange={(e) => setActionReason(e.target.value)} placeholder="Explique o motivo desta ação..." rows={3} />
              </label>
              <div className="admin-actions">
                <button className="primary-button" onClick={executeAction}><BadgeCheck /> Confirmar ação</button>
                <button className="ghost-button" onClick={() => { setActionMode(null); setActionReason(''); setActionValue(''); }}>Cancelar</button>
              </div>
            </div>
          )}
        </div>

        <div className="customer-sections-grid">
          <div className="customer-section-card">
            <h4><ShoppingBag /> Compras</h4>
            {customerOrders.length === 0 ? <p className="admin-empty-inline">Nenhuma compra registrada.</p> : (
              <div className="customer-mini-list">
                {customerOrders.map((o) => (
                  <div className="customer-mini-row" key={o.id}>
                    <span>{o.product_name || '—'}</span>
                    <b>{fmtBRL(Number(o.price))}</b>
                    <em className={`status-badge ${o.status}`}>{o.status}</em>
                    <small>{fmtDate(o.created_at)}</small>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="customer-section-card">
            <h4><Package /> Inventário</h4>
            {customerInventory.length === 0 ? <p className="admin-empty-inline">Inventário vazio.</p> : (
              <div className="customer-mini-list">
                {customerInventory.map((item) => (
                  <div className="customer-mini-row" key={item.id}>
                    <span>{item.product_name}</span>
                    <em className={`source-badge ${item.source}`}>{item.source}</em>
                    <small>{fmtDate(item.granted_at)}</small>
                    <button className="danger mini" onClick={() => revokeInventoryItem(item)}>Revogar</button>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="customer-section-card">
            <h4><Gift /> Presentes</h4>
            {customerGifts.length === 0 && customerTickets.length === 0 ? <p className="admin-empty-inline">Nenhum presente ou ticket.</p> : (
              <div className="customer-mini-list">
                {customerGifts.map((g) => (
                  <div className="customer-mini-row" key={g.id}>
                    <span className="mono">{g.code}</span>
                    <b>{fmtBRL(Number(g.value))}</b>
                    <em className={`status-badge ${g.status}`}>{g.status}</em>
                  </div>
                ))}
                {customerTickets.map((t) => (
                  <div className="customer-mini-row" key={t.id}>
                    <span className="mono">{t.code}</span>
                    <small>{t.prize}</small>
                    <em className={`status-badge ${t.status}`}>{t.status}</em>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="customer-section-card">
            <h4><HeartHandshake /> Trocas</h4>
            {customerTrades.length === 0 ? <p className="admin-empty-inline">Nenhuma troca registrada.</p> : (
              <div className="customer-mini-list">
                {customerTrades.map((t) => (
                  <div className="customer-mini-row" key={t.id}>
                    <span>{t.offer}</span>
                    <small>→ {t.looking}</small>
                    <em className={`status-badge ${t.status}`}>{t.status}</em>
                  </div>
                ))}
              </div>
            )}
          </div>
          <div className="customer-section-card full-width">
            <h4><History /> Histórico de ações administrativas</h4>
            {customerLog.length === 0 ? <p className="admin-empty-inline">Nenhuma ação administrativa registrada.</p> : (
              <div className="customer-mini-list">
                {customerLog.map((entry) => (
                  <div className="customer-log-row" key={entry.id}>
                    <em className={`action-badge ${entry.action}`}>{entry.action}</em>
                    <span>{entry.reason}</span>
                    {entry.details && <small>{entry.details}</small>}
                    <small>por {entry.manager_email}</small>
                    <small>{fmtDate(entry.created_at)}</small>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="admin-list-section">
      <div className="admin-list-heading">
        <div>
          <div className="eyebrow purple">CLIENTES</div>
          <h3>{customers.length} cadastrados</h3>
        </div>
        <Users />
      </div>
      <div className="toolbar">
        <div className="search-box">
          <Search />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar por e-mail, apelido ou função..." />
        </div>
      </div>
      {customers.length === 0 ? (
        <div className="empty-state"><Users /><strong>Nenhum cliente cadastrado.</strong><span>Os clientes aparecerão aqui após criarem conta.</span></div>
      ) : filtered.length === 0 ? (
        <div className="empty-state"><Search /><strong>Nenhum resultado.</strong><span>Tente outro termo de busca.</span></div>
      ) : (
        <div className="admin-table">
          <div className="admin-table-head">
            <span>Cliente</span>
            <span>Função</span>
            <span>Nível</span>
            <span>Pontos</span>
            <span>Status</span>
            <span>Cadastro</span>
          </div>
          {filtered.map((c) => {
            const pts = points.find((p) => p.customer_email === c.email);
            return (
              <div className="admin-table-row clickable" key={c.id} onClick={() => setSelectedId(c.id)}>
                <span>{c.nick ? `${c.nick} · ${c.email}` : c.email}</span>
                <em className={`role-badge ${c.role}`}>{c.role === 'manager' ? 'Gerente' : 'Cliente'}</em>
                <b>Nv {c.level ?? 1}</b>
                <b>{pts?.balance ?? 0} pts</b>
                <em className={`status-badge ${c.is_banned ? 'banned' : 'active'}`}>{c.is_banned ? 'Banido' : 'Ativo'}</em>
                <small>{fmtDate(c.created_at)}</small>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function TradesTab({ trades, onChanged, onNotice }: { trades: TradeOffer[]; onChanged: () => Promise<void>; onNotice: (message: string) => void }) {
  const updateStatus = async (trade: TradeOffer, status: string) => {
    const { error: updateError } = await supabase.from('trade_offers').update({ status, updated_at: new Date().toISOString() }).eq('id', trade.id);
    if (updateError) {
      onNotice('Não foi possível atualizar a troca.');
      return;
    }
    await onChanged();
    onNotice(`Troca marcada como ${status}.`);
  };

  return (
    <div className="admin-list-section">
      <div className="admin-list-heading">
        <div>
          <div className="eyebrow purple">TROCAS DA COMUNIDADE</div>
          <h3>{trades.length} ofertas</h3>
        </div>
        <HeartHandshake />
      </div>
      {trades.length === 0 ? (
        <div className="empty-state"><HeartHandshake /><strong>Nenhuma troca registrada.</strong><span>As trocas propostas pela comunidade aparecerão aqui.</span></div>
      ) : (
        <div className="admin-table">
          <div className="admin-table-head">
            <span>Jogo</span>
            <span>Oferece</span>
            <span>Procura</span>
            <span>Usuário</span>
            <span>Status</span>
            <span>Ações</span>
          </div>
          {trades.map((trade) => (
            <div className="admin-table-row" key={trade.id}>
              <span>{trade.game}</span>
              <span>{trade.offer}</span>
              <small>{trade.looking}</small>
              <small>{trade.user_email}</small>
              <em className={`status-badge ${trade.status}`}>{trade.status}</em>
              <div className="admin-row-actions">
                {trade.status === 'open' && <button onClick={() => updateStatus(trade, 'matched')}>Marcar como combinada</button>}
                {trade.status === 'matched' && <button onClick={() => updateStatus(trade, 'closed')}>Fechar</button>}
                {trade.status !== 'reported' && <button className="danger" onClick={() => updateStatus(trade, 'reported')}>Denunciar</button>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function GoldenTicketTab({ tickets, onChanged, onNotice }: { tickets: GoldenTicket[]; onChanged: () => Promise<void>; onNotice: (message: string) => void }) {
  const [code, setCode] = useState('');
  const [prize, setPrize] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const generateCode = () => `GOLD-${Math.random().toString(36).slice(2, 8).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const create = async () => {
    if (!prize.trim()) {
      setError('Descreva o prêmio do Ticket Dourado.');
      return;
    }
    const finalCode = code.trim() || generateCode();
    const { error: insertError } = await supabase.from('golden_tickets').insert({
      code: finalCode,
      prize: prize.trim(),
      customer_email: email.trim(),
      status: 'unused',
      expires_at: null,
    });
    if (insertError) {
      setError('Não foi possível criar o ticket.');
      return;
    }
    setCode('');
    setPrize('');
    setEmail('');
    setError('');
    await onChanged();
    onNotice(`Ticket Dourado ${finalCode} criado.`);
  };

  const updateStatus = async (ticket: GoldenTicket, status: string) => {
    const { error: updateError } = await supabase.from('golden_tickets').update({ status, updated_at: new Date().toISOString() }).eq('id', ticket.id);
    if (updateError) {
      onNotice('Não foi possível atualizar o ticket.');
      return;
    }
    await onChanged();
    onNotice(`Ticket ${ticket.code} marcado como ${status}.`);
  };

  return (
    <div className="admin-grid">
      <section className="admin-form-card">
        <div className="eyebrow purple"><Crown /> TICKET DOURADO</div>
        <h3>Emitir novo ticket</h3>
        <label>Código (opcional)
          <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Gera automaticamente se vazio" />
        </label>
        <label>Prêmio
          <input value={prize} onChange={(e) => setPrize(e.target.value)} placeholder="Ex: 100 moedas + skin rara" />
        </label>
        <label>Cliente (e-mail, opcional)
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@email.com" />
        </label>
        {error && <div className="auth-error">{error}</div>}
        <div className="admin-actions">
          <button className="primary-button" onClick={create}><Plus /> Criar Ticket Dourado</button>
        </div>
      </section>
      <section className="admin-list-card">
        <div className="admin-list-heading">
          <div>
            <div className="eyebrow purple">TICKETS EMITIDOS</div>
            <h3>{tickets.length} tickets</h3>
          </div>
          <Ticket />
        </div>
        {tickets.length === 0 ? (
          <div className="empty-state"><Ticket /><strong>Nenhum ticket emitido.</strong><span>Crie o primeiro acima.</span></div>
        ) : (
          <div className="admin-table">
            <div className="admin-table-head">
              <span>Código</span>
              <span>Prêmio</span>
              <span>Cliente</span>
              <span>Status</span>
              <span>Ações</span>
            </div>
            {tickets.map((ticket) => (
              <div className="admin-table-row" key={ticket.id}>
                <span className="mono">{ticket.code}</span>
                <span>{ticket.prize}</span>
                <small>{ticket.customer_email || '—'}</small>
                <em className={`status-badge ${ticket.status}`}>{ticket.status}</em>
                <div className="admin-row-actions">
                  {ticket.status === 'unused' && <button onClick={() => updateStatus(ticket, 'redeemed')}>Resgatar</button>}
                  {ticket.status !== 'revoked' && <button className="danger" onClick={() => updateStatus(ticket, 'revoked')}>Revogar</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function EventsTab({ events, onChanged, onNotice }: { events: EventItem[]; onChanged: () => Promise<void>; onNotice: (message: string) => void }) {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [type, setType] = useState('standard');
  const [error, setError] = useState('');

  const create = async () => {
    if (!name.trim()) {
      setError('Defina o nome do evento.');
      return;
    }
    const { error: insertError } = await supabase.from('events').insert({
      name: name.trim(),
      description: description.trim(),
      type,
      is_active: false,
    });
    if (insertError) {
      setError('Não foi possível criar o evento.');
      return;
    }
    setName('');
    setDescription('');
    setType('standard');
    setError('');
    await onChanged();
    onNotice('Evento criado (desativado por padrão).');
  };

  const toggle = async (event: EventItem) => {
    const { error: updateError } = await supabase.from('events').update({ is_active: !event.is_active, updated_at: new Date().toISOString() }).eq('id', event.id);
    if (updateError) {
      onNotice('Não foi possível alterar o evento.');
      return;
    }
    await onChanged();
    onNotice(event.is_active ? 'Evento desativado.' : 'Evento ativado.');
  };

  const remove = async (event: EventItem) => {
    if (!window.confirm(`Excluir o evento ${event.name}?`)) return;
    const { error: deleteError } = await supabase.from('events').delete().eq('id', event.id);
    if (deleteError) {
      onNotice('Não foi possível excluir o evento.');
      return;
    }
    await onChanged();
    onNotice('Evento excluído.');
  };

  return (
    <div className="admin-grid">
      <section className="admin-form-card">
        <div className="eyebrow purple"><CalendarDays /> NOVO EVENTO</div>
        <h3>Criar evento</h3>
        <label>Nome
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Nome do evento" />
        </label>
        <label>Descrição
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Descrição do evento" rows={3} />
        </label>
        <label>Tipo
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="standard">Padrão</option>
            <option value="christmas">Natal</option>
            <option value="casino">Cassino</option>
          </select>
        </label>
        {error && <div className="auth-error">{error}</div>}
        <div className="admin-actions">
          <button className="primary-button" onClick={create}><Plus /> Criar evento</button>
        </div>
        <small className="admin-note">Eventos começam desativados. Ative manualmente após criar.</small>
      </section>
      <section className="admin-list-card">
        <div className="admin-list-heading">
          <div>
            <div className="eyebrow purple">EVENTOS CADASTRADOS</div>
            <h3>{events.length} eventos</h3>
          </div>
          <CalendarDays />
        </div>
        {events.length === 0 ? (
          <div className="empty-state"><CalendarDays /><strong>Nenhum evento.</strong><span>Crie o primeiro acima.</span></div>
        ) : (
          <div className="admin-event-list">
            {events.map((event) => (
              <div className={`admin-event-card ${event.is_active ? 'active' : 'inactive'}`} key={event.id}>
                <div className="admin-event-info">
                  <strong>{event.name}</strong>
                  <small>{event.description || 'Sem descrição'}</small>
                  <div className="admin-event-meta">
                    <em className={`type-badge ${event.type}`}>{event.type}</em>
                    <em className={`status-badge ${event.is_active ? 'active' : 'inactive'}`}>{event.is_active ? 'Ativo' : 'Inativo'}</em>
                  </div>
                </div>
                <div className="admin-row-actions">
                  <button onClick={() => toggle(event)}>{event.is_active ? 'Desativar' : 'Ativar'}</button>
                  <button className="danger" onClick={() => remove(event)}><Trash2 /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function DiscountsTab({ discounts, catalog, onChanged, onNotice }: { discounts: Discount[]; catalog: Product[]; onChanged: () => Promise<void>; onNotice: (message: string) => void }) {
  const [code, setCode] = useState('');
  const [percent, setPercent] = useState('');
  const [productId, setProductId] = useState('');
  const [error, setError] = useState('');

  const create = async () => {
    const pct = Number(percent.replace(',', '.'));
    if (!code.trim() || !Number.isFinite(pct) || pct < 0 || pct > 100) {
      setError('Preencha o código e um percentual válido (0-100).');
      return;
    }
    const { error: insertError } = await supabase.from('discounts').insert({
      code: code.trim(),
      percent: pct,
      product_id: productId || null,
      is_active: false,
    });
    if (insertError) {
      setError('Não foi possível criar o desconto.');
      return;
    }
    setCode('');
    setPercent('');
    setProductId('');
    setError('');
    await onChanged();
    onNotice('Desconto criado (desativado por padrão).');
  };

  const toggle = async (discount: Discount) => {
    const { error: updateError } = await supabase.from('discounts').update({ is_active: !discount.is_active, updated_at: new Date().toISOString() }).eq('id', discount.id);
    if (updateError) {
      onNotice('Não foi possível alterar o desconto.');
      return;
    }
    await onChanged();
    onNotice(discount.is_active ? 'Desconto desativado.' : 'Desconto ativado.');
  };

  const remove = async (discount: Discount) => {
    if (!window.confirm(`Excluir o desconto ${discount.code}?`)) return;
    const { error: deleteError } = await supabase.from('discounts').delete().eq('id', discount.id);
    if (deleteError) {
      onNotice('Não foi possível excluir o desconto.');
      return;
    }
    await onChanged();
    onNotice('Desconto excluído.');
  };

  return (
    <div className="admin-grid">
      <section className="admin-form-card">
        <div className="eyebrow purple"><Tag /> NOVO DESCONTO</div>
        <h3>Criar desconto</h3>
        <label>Código
          <input value={code} onChange={(e) => setCode(e.target.value)} placeholder="Ex: NATAL20" />
        </label>
        <label>Percentual (%)
          <input value={percent} onChange={(e) => setPercent(e.target.value)} placeholder="20" inputMode="decimal" />
        </label>
        <label>Produto (opcional)
          <select value={productId} onChange={(e) => setProductId(e.target.value)}>
            <option value="">Todos os produtos</option>
            {catalog.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </label>
        {error && <div className="auth-error">{error}</div>}
        <div className="admin-actions">
          <button className="primary-button" onClick={create}><Plus /> Criar desconto</button>
        </div>
      </section>
      <section className="admin-list-card">
        <div className="admin-list-heading">
          <div>
            <div className="eyebrow purple">DESCONTOS CADASTRADOS</div>
            <h3>{discounts.length} descontos</h3>
          </div>
          <Tag />
        </div>
        {discounts.length === 0 ? (
          <div className="empty-state"><Tag /><strong>Nenhum desconto.</strong><span>Crie o primeiro acima.</span></div>
        ) : (
          <div className="admin-table">
            <div className="admin-table-head">
              <span>Código</span>
              <span>Percentual</span>
              <span>Produto</span>
              <span>Status</span>
              <span>Ações</span>
            </div>
            {discounts.map((d) => {
              const product = catalog.find((p) => p.id === d.product_id);
              return (
                <div className="admin-table-row" key={d.id}>
                  <span className="mono">{d.code}</span>
                  <b>{Number(d.percent)}%</b>
                  <small>{product?.name ?? 'Todos'}</small>
                  <em className={`status-badge ${d.is_active ? 'active' : 'inactive'}`}>{d.is_active ? 'Ativo' : 'Inativo'}</em>
                  <div className="admin-row-actions">
                    <button onClick={() => toggle(d)}>{d.is_active ? 'Desativar' : 'Ativar'}</button>
                    <button className="danger" onClick={() => remove(d)}><Trash2 /></button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>
    </div>
  );
}

function PointsTab({ points, onChanged, onNotice }: { points: CustomerPoints[]; onChanged: () => Promise<void>; onNotice: (message: string) => void }) {
  const [email, setEmail] = useState('');
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');

  const adjust = async (delta: number) => {
    const amt = Number(amount);
    if (!email.trim() || !Number.isFinite(amt) || amt <= 0) {
      setError('Informe e-mail e quantidade válidos.');
      return;
    }
    const existing = points.find((p) => p.customer_email === email.trim());
    if (existing) {
      const newBalance = Math.max(0, existing.balance + delta * amt);
      const { error: updateError } = await supabase.from('customer_points').update({ balance: newBalance, updated_at: new Date().toISOString() }).eq('id', existing.id);
      if (updateError) {
        setError('Não foi possível ajustar os pontos.');
        return;
      }
    } else {
      const { error: insertError } = await supabase.from('customer_points').insert({
        customer_email: email.trim(),
        balance: Math.max(0, delta * amt),
      });
      if (insertError) {
        setError('Não foi possível criar o registro de pontos.');
        return;
      }
    }
    setEmail('');
    setAmount('');
    setError('');
    await onChanged();
    onNotice(`${delta > 0 ? '+' : '-'}${amt} pontos ajustados para ${email}.`);
  };

  return (
    <div className="admin-grid">
      <section className="admin-form-card">
        <div className="eyebrow purple"><Coins /> PONTOS DE FIDELIDADE</div>
        <h3>Ajustar pontos</h3>
        <label>Cliente (e-mail)
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@email.com" />
        </label>
        <label>Quantidade
          <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="100" inputMode="numeric" />
        </label>
        {error && <div className="auth-error">{error}</div>}
        <div className="admin-actions">
          <button className="primary-button" onClick={() => adjust(1)}><Plus /> Adicionar</button>
          <button className="ghost-button" onClick={() => adjust(-1)}><Trash2 /> Remover</button>
        </div>
      </section>
      <section className="admin-list-card">
        <div className="admin-list-heading">
          <div>
            <div className="eyebrow purple">SALDOS DE PONTOS</div>
            <h3>{points.length} clientes</h3>
          </div>
          <Coins />
        </div>
        {points.length === 0 ? (
          <div className="empty-state"><Coins /><strong>Nenhum registro de pontos.</strong><span>Ajuste pontos acima.</span></div>
        ) : (
          <div className="admin-table">
            <div className="admin-table-head">
              <span>Cliente</span>
              <span>Saldo</span>
              <span>Atualizado</span>
            </div>
            {points.map((p) => (
              <div className="admin-table-row" key={p.id}>
                <span>{p.customer_email}</span>
                <b>{p.balance} pts</b>
                <small>{fmtDate(p.created_at)}</small>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function GiftCardsTab({ giftCards, onChanged, onNotice }: { giftCards: GiftCard[]; onChanged: () => Promise<void>; onNotice: (message: string) => void }) {
  const [value, setValue] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const generateCode = () => `GC-${Math.random().toString(36).slice(2, 8).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;

  const create = async () => {
    const val = Number(value.replace(',', '.'));
    if (!Number.isFinite(val) || val <= 0) {
      setError('Informe um valor válido.');
      return;
    }
    const code = generateCode();
    const { error: insertError } = await supabase.from('gift_cards').insert({
      code,
      value: val,
      customer_email: email.trim(),
      status: 'unused',
    });
    if (insertError) {
      setError('Não foi possível criar o gift card.');
      return;
    }
    setValue('');
    setEmail('');
    setError('');
    await onChanged();
    onNotice(`Gift card ${code} criado com valor ${fmtBRL(val)}.`);
  };

  const updateStatus = async (card: GiftCard, status: string) => {
    const { error: updateError } = await supabase.from('gift_cards').update({ status, updated_at: new Date().toISOString() }).eq('id', card.id);
    if (updateError) {
      onNotice('Não foi possível atualizar o gift card.');
      return;
    }
    await onChanged();
    onNotice(`Gift card ${card.code} marcado como ${status}.`);
  };

  return (
    <div className="admin-grid">
      <section className="admin-form-card">
        <div className="eyebrow purple"><Gift /> GIFT CARDS</div>
        <h3>Emitir gift card</h3>
        <label>Valor (R$)
          <input value={value} onChange={(e) => setValue(e.target.value)} placeholder="50,00" inputMode="decimal" />
        </label>
        <label>Cliente (e-mail, opcional)
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="voce@email.com" />
        </label>
        {error && <div className="auth-error">{error}</div>}
        <div className="admin-actions">
          <button className="primary-button" onClick={create}><Plus /> Emitir gift card</button>
        </div>
      </section>
      <section className="admin-list-card">
        <div className="admin-list-heading">
          <div>
            <div className="eyebrow purple">GIFT CARDS EMITIDOS</div>
            <h3>{giftCards.length} cards</h3>
          </div>
          <Gift />
        </div>
        {giftCards.length === 0 ? (
          <div className="empty-state"><Gift /><strong>Nenhum gift card.</strong><span>Emita o primeiro acima.</span></div>
        ) : (
          <div className="admin-table">
            <div className="admin-table-head">
              <span>Código</span>
              <span>Valor</span>
              <span>Cliente</span>
              <span>Status</span>
              <span>Ações</span>
            </div>
            {giftCards.map((card) => (
              <div className="admin-table-row" key={card.id}>
                <span className="mono">{card.code}</span>
                <b>{fmtBRL(Number(card.value))}</b>
                <small>{card.customer_email || '—'}</small>
                <em className={`status-badge ${card.status}`}>{card.status}</em>
                <div className="admin-row-actions">
                  {card.status === 'unused' && <button onClick={() => updateStatus(card, 'redeemed')}>Resgatar</button>}
                  {card.status !== 'revoked' && <button className="danger" onClick={() => updateStatus(card, 'revoked')}>Revogar</button>}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
